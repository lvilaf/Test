var dotenv = require('dotenv').config();

module.exports = {
	port                : process.env.PORT,

    ORACLEDB            : process.env.ORACLEDB,
    DB_USER             : process.env.DB_USER,
    DB_PASS             : process.env.DB_PASS,

    PROXY               : process.env.PROXY,

    SECRET_TOKEN        : process.env.SECRET_TOKEN,

    PRIVATE_KEY         : process.env.PRIVATE_KEY,
	
    SMTP_HOST           : process.env.SMTP_HOST,
    SMTP_PORT           : process.env.SMTP_PORT,

    CLAVEUNICA_REDIRECT : process.env.CLAVEUNICA_REDIRECT,

    ORIGIN_AUTH_DESA    : process.env.ORIGIN_AUTH_DESA,
    ORIGIN_AUTH_TEST    : process.env.ORIGIN_AUTH_TEST,
    ORIGIN_AUTH_PROD    : process.env.ORIGIN_AUTH_PROD,

    REDIRECT_URI_DESA  : process.env.REDIRECT_URI_DESA,
    CLIENT_ID_DESA     : process.env.CLIENT_ID_DESA,
    CLIENT_SECRET_DESA : process.env.CLIENT_SECRET_DESA,

    REDIRECT_URI_TEST  : process.env.REDIRECT_URI_TEST,
    CLIENT_ID_TEST     : process.env.CLIENT_ID_TEST,
    CLIENT_SECRET_TEST : process.env.CLIENT_SECRET_TEST,

    REDIRECT_URI_PROD  : process.env.REDIRECT_URI_PROD,
    CLIENT_ID_PROD     : process.env.CLIENT_ID_PROD,
    CLIENT_SECRET_PROD : process.env.CLIENT_SECRET_PROD,

    API_ONEREG_DESA    : process.env.API_ONEREG_DESA,
    APPKEY_DESA        : process.env.APPKEY_DESA,
    IDAPP_DESA         : process.env.IDAPP_DESA,

    API_ONEREG_TEST    : process.env.API_ONEREG_TEST,
    APPKEY_TEST        : process.env.APPKEY_TEST,
    IDAPP_TEST         : process.env.IDAPP_TEST,

    API_ONEREG_PROD    : process.env.API_ONEREG_PROD,
    APPKEY_PROD        : process.env.APPKEY_PROD,
    IDAPP_PROD         : process.env.IDAPP_PROD,

    URL_APILDAP_DESA    : process.env.URL_APILDAP_DESA,
    URL_APILDAP_TEST    : process.env.URL_APILDAP_TEST,
    URL_APILDAP_PROD    : process.env.URL_APILDAP_PROD,

    FLAG_LOGIN          : process.env.FLAG_LOGIN,

    TIEMPO_DESA         : process.env.TIEMPO_DESA,
    UNIDAD_DESA         : process.env.UNIDAD_DESA,
    
    TIEMPO              : process.env.TIEMPO,
    UNIDAD              : process.env.UNIDAD,

    REPO_HOME           : process.env.REPO_HOME,
    REPO_TEMP           : process.env.REPO_TEMP,
    REPO_USER           : process.env.REPO_USER,

    REPO_HOST_PROD      : process.env.REPO_HOST_PROD,
    REPO_PASS_PROD      : process.env.REPO_PASS_PROD,

    REPO_HOST_TEST      : process.env.REPO_HOST_TEST,
    REPO_PASS_TEST      : process.env.REPO_PASS_TEST,

    REPO_HOST_DESA      : process.env.REPO_HOST_DESA,
    REPO_PASS_DESA      : process.env.REPO_PASS_DESA,

    SECRET_KEY_DESA    : process.env.SECRET_KEY_DESA,
    SECRET_KEY_TEST    : process.env.SECRET_KEY_TEST,
    SECRET_KEY_PROD    : process.env.SECRET_KEY_PROD,
    URI_CAPTCHA        : process.env.URI_CAPTCHA,
    
    ESBPERSONALWS      : process.env.ESBPERSONALWS
};