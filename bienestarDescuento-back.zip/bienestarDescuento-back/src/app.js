'use strict';

const express = require('express');
const bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var path = require('path');
const app = express();
const api = require('./routes/routes');
var cors = require('cors');


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.disable('x-powered-by');

// Configurar cabeceras y cors
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.setHeader('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
    next();
});
app.use(cors({ origin: '*', optionsSuccessStatus: 200 }));

app.use(bodyParser.json({ limit: '50mb' })); // entender formato json
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true, parameterLimit: 50000 })); // entender datos que llegan de inputs de form
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


app.use('/api', api);

module.exports = app;