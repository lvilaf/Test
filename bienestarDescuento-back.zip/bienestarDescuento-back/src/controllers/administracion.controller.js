'use-strict';
const administracionModel = require('../models/administracion.model');
const emailSender = require('../helpers/email');
const utilModel = require('../models/util.model');
const usuarioModel = require('../models/usuario.model');
const { route } = require('../app');

async function listaRut(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        try {
            respuesta = await administracionModel.listaRut();

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/listaRut: " + err);
            res.status(400).send({status: 501, message: "Error en controller/listaRut" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function mantGrabaUsuario(req, res) {
    let respuesta;
    let v_listaPef='';
    if (req.body.uipTran) {
        if (req.body.uperfil!=null){
            for (let uno of req.body.uperfil){
                if (v_listaPef==''){
                    v_listaPef=(uno.uidPerfil).toString();
                }else{
                    v_listaPef+=','+(uno.uidPerfil).toString();
                }
            }    
        }
        let parametro = {
            tipo       :'II',
            idUsuario  :null,
            idAutoridad:req.body.uidAutoridad,
            rut        :req.body.urut, 
            dv         :req.body.udv,
            apUno      :req.body.uapUno,
            apDos      :req.body.uapDos,
            nombre     :req.body.unombre,
            email      :req.body.uemail,
            username   :req.body.uusername,
            obs        :req.body.uobs,
            vigente    :'S',
            listaPef   :v_listaPef,
            idUsuarioP :req.body.uidUsuarioP,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await administracionModel.mantencionUsuario(parametro);
            res.status(200).json(respuesta);
        } catch (err) {
            console.error("Error en controller/mantGrabaUsuario: " + err);
            res.status(400).send({status: 501, message: "Error en controller/mantGrabaUsuario "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function mantActualizaUsuario(req, res) {
    let respuesta;
    let v_listaPef='';
    if (req.body.uipTran) {
        if (req.body.uperfil!=null){
            for (let uno of req.body.uperfil){
                if (v_listaPef==''){
                    v_listaPef=(uno.uidPerfil).toString();
                }else{
                    v_listaPef+=','+(uno.uidPerfil).toString();
                }
            }
        }
        let parametro = {
            tipo       :'UP',
            idUsuario  :req.body.uidUsuario,
            idAutoridad:req.body.uidAutoridad,
            rut        :req.body.urut, 
            dv         :req.body.udv,            
            apUno      :req.body.uapUno,
            apDos      :req.body.uapDos,
            nombre     :req.body.unombre,
            email      :req.body.uemail,
            username   :req.body.uusername,
            obs        :req.body.uobs,
            vigente    :req.body.uvigente,
            listaPef   :v_listaPef,
            idUsuarioP :req.body.uidUsuarioP,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await administracionModel.mantencionUsuario(parametro);
            res.status(200).json(respuesta);
        } catch (err) {
            console.error("Error en controller/mantActualizaUsuario: " + err);
            res.status(400).send({status: 501, message: "Error en controller/mantActualizaUsuario "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function mantBorraUsuario(req, res) {
    let respuesta;
    let v_listaPef='';
    if (req.body.uipTran) {
        let parametro = {
            tipo      :'DD',
            idUsuario :req.body.uidUsuario,
            idUsuarioP:req.body.uidUsuarioP,
            ipTran    :req.body.uipTran
        }
        try {
            respuesta = await administracionModel.mantencionUsuario(parametro);
            res.status(200).json(respuesta);
        } catch (err) {
            console.error("Error en controller/mantBorraUsuario: " + err);
            res.status(400).send({status: 501, message: "Error en controller/mantBorraUsuario "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

module.exports = {
    listaRut,
    mantGrabaUsuario,
    mantActualizaUsuario,
    mantBorraUsuario
};