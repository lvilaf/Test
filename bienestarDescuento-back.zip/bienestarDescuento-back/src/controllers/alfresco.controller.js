'use-strict';
const md5 = require('md5');
var formidable = require('formidable');
var FormData = require('form-data');
var fs = require('fs');
var http = require('http');
const fetch = require("node-fetch");
const helpersAlfresco = require('../helpers/alfresco');
const config = require('../../config/config');
const path = require('path');
//const base64 = require('base64-stream');

async function obtenerVersion(req, res) {
    let version = "1.0.0.0 21-05-2020";
    res.status(200).send({ status: 200, message: version });
};

async function subirAlfresco(req, res) {
    const form = formidable({ multiples: true });
    form.parse(req, async(err, fields, files) => {
        if (err) {
            throw (err);
        }
        var jsonval = JSON.parse(fields.data);

        if (files.archivo.size > 50000000) { //50MB app
            res.status(418).send({ status: 418, message: "El archivo excede el tamaño permitido" });
        } else {
            try {
                let respuesta = await helpersAlfresco.subirAlfresco(req, jsonval.uano, jsonval.umes, jsonval.uidAutoridad, config.REPO_TEMP, files);
                var resp;
                if (respuesta.status == 200) {
                    resp = {
                        status: 200,
                        message: "OK"
                    };
                } else {
                    resp = {
                        status: 300,
                        message: "Ocurrió un error al subir el archivo " + files.archivo.originalFilename
                    };
                }
                res.status(200);
                res.json(resp);
            } catch (err) {
                console.log(err);

                console.log("error al obtener estado " + err);
                res.status(500).send({ status: 500, message: "Error interno del servidor" });
            }
        }
    });
};

async function bajarAlfresco(req, res) {
    try {
        let data={
            idAutoridad  :req.body.uidAutoridad,
            ano          :req.body.uano,
            mes          :req.body.umes
        }
        let yyy;
        res.setHeader('Content-Type', 'application/octet-stream');
        let salida = await helpersAlfresco.bajarAlfresco(req,data);

//        console.log(salida);

        res.status(200).send({ status: 200, message: "", salida:salida.obj.toString('base64') });
//        res.json(respuesta);
//        console.log(res);
    } catch (err) {
        console.log("error al obtener estado " + err);
        res.status(500).send({ status: 500, message: "Error interno del servidor" });
    }
};

async function renombrarAlfresco(req, res) {
    let resp;
    if (req.body.uipTran) {
        let data={
            idAutoridad : req.body.uidAutoridad,
            ano         : req.body.uano,
            mes         : req.body.umes
        }
        try {
            let respuesta = await helpersAlfresco.renombrarAlfresco(req, data);

            if (respuesta.status == 200) {
                resp = {
                    status   : 200,
                    message  : "OK",
                    lista    : respuesta.lista
                };
            } else {
                resp = {
                    status  : respuesta.status,
                    message : respuesta.message
                };
            }
            res.status(200);
            res.json(resp);
        } catch (err) {
            // console.log(err);  
            // console.log("error al obtener estado " + err);
            res.status(500).send({ status: 500, message: "Error interno del servidor" });
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
};

async function borrarAlfresco(req, res) {
    let resp;
    if (req.body.uipTran) {
        let data={
            idAutoridad : req.body.uidAutoridad,
            ano         : req.body.uano,
            mes         : req.body.umes,
            fileName    : req.body.ufileName
        }
        try {
            let respuesta = await helpersAlfresco.borrarAlfresco(req, data);

            if (respuesta.status == 200) {
                resp = {
                    status   : 200,
                    message  : "OK"
                };
            } else {
                resp = {
                    status: 300,
                    message: "Ocurrió un error al borrar el archivo "+data.ano+'_'+data.mes+'_'+data.idAutoridad+'_'+data.fileName
                };
            }
            res.status(200);
            res.json(resp);
        } catch (err) {
            console.log(err);  
            console.log("error al obtener estado " + err);
            res.status(500).send({ status: 500, message: "Error interno del servidor" });
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
};

module.exports = {
    subirAlfresco,
    bajarAlfresco,
    renombrarAlfresco,
    borrarAlfresco,
    obtenerVersion
};