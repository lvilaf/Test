'use-strict';
const archivoModel = require('../models/archivo.model');
const emailSender = require('../helpers/email');
const utilModel = require('../models/util.model');
const usuarioModel = require('../models/usuario.model');
//
const { formatoXML } = require('../helpers/archivo')
const multer = require('multer');
const xml2js = require('xml2js');
// 
const upload = multer().single('excelFile');

async function leeArchivo(req, res) {
    if (req.body.uipTran) {
        let archivo = {
            idAutoridad:req.body.uidAutoridad,
            ano        :req.body.uano,
            mes        :req.body.umes,
            idUsuario  :req.body.uidUsuario,
            fecArchivo :req.body.ufecArchivo,
            fileName   :req.body.ufileName,
            extension  :req.body.uextension,
            ipTran     :req.body.uipTran
        };
        try {
            let payload = await archivoModel.leeArchivo(archivo);  

            res.status(200).json(payload);
        } catch (err) {
            console.error("Error en controller/leeArchivo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeArchivo" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaArchivo(req, res) {
    let respuesta;

    if (req.body.uipTran) {
        let archivo={
            idAutoridad:req.body.uidAutoridad,
            ano        :req.body.uano,
            mes        :req.body.umes,
            idUsuario  :req.body.uidUsuario,
            fecArchivo :req.body.ufecArchivo,
            obs        :req.body.uobs,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await archivoModel.grabaArchivo(req,archivo);  
            if (respuesta.status == 200) { 
                res.status(200).json({status:respuesta.status,message:respuesta.message,obj:respuesta.obj});
            }else {
                res.status(400).json({status:respuesta.status,message:respuesta.message,obj:respuesta.obj});
            }
        } catch (err) {
            console.error("Error en controller/grabaArchivo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaArchivo" })            
        }    
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function actualizaArchivo(req, res) {
    let respuesta;

    if (req.body.uipTran) {
        let archivo={
            idAutoridad:req.body.uidAutoridad,
            ano        :req.body.uano,
            mes        :req.body.umes,
            idUsuario  :req.body.uidUsuario,
            fecArchivo :req.body.ufecArchivo,
            fileName   :req.body.ufileName,
            obs        :req.body.uobs,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await archivoModel.actualizaArchivo(req,archivo);  
            res.status(200).json(respuesta);
        } catch (err) {
            console.error("Error en controller/actualizaArchivo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaArchivo" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function borraArchivo(req, res) {
    let respuesta;

    if (req.body.uipTran) {
        let archivo={
            idAutoridad:req.body.uidAutoridad,
            ano        :req.body.uano,
            mes        :req.body.umes,
            fileName   :req.body.ufileName,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await archivoModel.borraArchivo(req,archivo);  
            res.status(200).json({status:respuesta.status,message:respuesta.message});
        } catch (err) {
            console.error("Error en controller/borraArchivo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/borraArchivo" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////

async function convertirArchivoExcel(req, res){
    try {
      upload(req, res, (err) => {
        if (err) {
          console.error('Error al convertir el archivo:', err);
          return res.status(500).send('Error al convertir el archivo');
        }
  
        const xmlOutput = formatoXML(req);
  
        if (xmlOutput) {
          res.status(200).type('application/xml').send(xmlOutput);
        } else {
          console.error('Error al generar el XML');
          res.status(500).send('Error al generar el XML');
        }
      });
    } catch (error) {
      console.error('Error inesperado:', error);
      res.status(500).send('Error interno en el servidor');
    }
  };

  async function leerArchivoExcelaJSON(req, res) {
    try {
      upload(req, res, (err) => {
        if (err) {
          console.error('Error al leer el archivo a JSON:', err);
          return res.status(500).send('Error al leer el archivo a JSON');
        }
  
        const result = formatoXML(req);
  
        xml2js.parseString(result, (err, jsonData) => {
          if (err) {
            console.error('Error al parsear XML a JSON:', err);
            res.status(500).send('Error al parsear XML a JSON');
          } else {
            res.setHeader('Content-Type', 'application/json');
            res.status(200).json(jsonData);
          }
        });
      });
    } catch (error) {
      console.error('Error inesperado:', error);
      res.status(500).send('Error interno en el servidor');
    }
  }



module.exports = {
    leeArchivo,
    grabaArchivo,
    actualizaArchivo,
    borraArchivo,
    convertirArchivoExcel,
    leerArchivoExcelaJSON
};