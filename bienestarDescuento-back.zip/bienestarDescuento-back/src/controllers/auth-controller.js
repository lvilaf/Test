const helpersOneReg       = require('../helpers/oneReg');
const helpersClaveUnica   = require('../helpers/claveUnica');
const helpersToken        = require('../helpers/token');
const helpersLdap         = require('../helpers/ldap');
const helpersExternalDeps = require('../helpers/externaldeps');
const service             = require('../services/services');
const config              = require('../../config/config');
const usuarioModel        = require('../models/usuario.model');
const utilModel           = require('../models/util.model');

/*****  Métodos Clave única ******/

 async function loginCu(req, res) {
    var clientId = '';
    var redirectUri = '';

    if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
        clientId    = config.CLIENT_ID_DESA;
        redirectUri = config.REDIRECT_URI_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        clientId    = config.CLIENT_ID_TEST;
        redirectUri = config.REDIRECT_URI_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        clientId    = config.CLIENT_ID_PROD;
        redirectUri = config.REDIRECT_URI_PROD;
    }else{
        res.status(400).send({status:400,message:'Origin NO Autorizado '+req.get('origin')});
    }
        
    try {
        var CSRFToken = await helpersToken.generateTokenCU();
        
        var url = config.CLAVEUNICA_REDIRECT + "openid/authorize" +
            "?client_id=" + clientId +
            "&redirect_uri=" + redirectUri +
            "&response_type=code" +
            "&scope=openid%20run%20name" +
            "&state=" + CSRFToken;
        
        res.status(200).send({ url: url });
    } catch (err) {
        res.status(500).send({ status: 400, message: "Error interno del servidor - generateTokenCU() :"+err });
    }
}

async function claveUnica(req, res) {
    var codex  = req.body.ucode;
    var statex = req.body.ustate;
    let resp= {
        status : 200,
        message: "Usuario No Autorizado/ No Existe"
    }

    try{
        var datos0;
        if (req.get('origin')== config.ORIGIN_AUTH_DESA || 
            req.get('origin')== config.ORIGIN_AUTH_TEST || 
            req.get('origin')== config.ORIGIN_AUTH_PROD) {
            datos0 = await helpersClaveUnica.obtieneAccessToken(req, codex, statex);
        }
        
        if (datos0.status!=200) 
            throw new Error(datos0.message);

        // var accToken = JSON.parse(datos0.obj);
        var datos = await helpersClaveUnica.obtieneDatos(datos0.obj.access_token);

        if (datos.status!=200) 
            throw new Error(datos.message);

        let v_idUsuario=null;
        let salida = await usuarioModel.leeUsuario({idUsuario:null,idAutoridad:null,apUno:null,apDos:null,nombre:null,
                                                    rut:datos.obj.RolUnico.numero,dv:datos.obj.RolUnico.DV,email:null,username:null,vigente:null}); 
        if (salida.status==200){
            if (salida.usuario[0].vigente=='S'){
                resp = {
                    status : 200,
                    message: "OK",
                    token  : service.createToken({rut:datos.obj.RolUnico.numero,ipTran:req.body.uipTran,origin:req.get('origin')}),
                    usuario: salida.usuario
                }
            }else{
                resp = {
                    status : 201,
                    message: 'Usuario No Vigente '
                }            
            }
            res.status(200);
            res.json(resp);
        }else{
            resp = {
                status : salida.status,
                message: salida.message
            }
        }
        res.status(200);
        res.json(resp);
    }catch(err){
        res.status(500).send({ status: 400, message: err.message });
    }
}

/*****  Métodos One Reg ******/

async function loginOneReg(req, res) {
    let resp;
    try {
        let runSplit = req.body.unumDoc.split("-");
        let datosLogin = {
            rut: Number(runSplit[0]),
            dv: runSplit[1],
            numdoc: '',
            idpais: 152,
            password: req.body.upassword
        }
        var logOk = await helpersOneReg.loginOneReg(req,datosLogin);

        if (logOk.status == 200) {
            let datos = datosLogin;
            delete datos.password;
            var persona = await helpersOneReg.infoPersona(req,datos);

            if (persona.status == 200) {
                let salida = await usuarioModel.leeUsuario({idUsuario:null,idAutoridad:null,apUno:null,apDos:null,nombre:null,
                                                               rut:datosLogin.rut,dv:datosLogin.dv,email:null,username:null,vigente:null}); 
                if (salida.status==200){
                    if (salida.usuario[0].vigente=='S'){
                        resp = {
                            status : 200,
                            message: "OK",
                            token  : service.createToken({rut:datosLogin.rut,ipTran:req.body.uipTran,origin:req.get('origin')}),
                            usuario: salida.usuario
                        }            
                    }else{
                        resp = {
                            status : 201,
                            message: 'Usuario No Vigente '
                        }            
                    }
                }
                res.status(200);
                res.json(resp);
            } else {
                let resp = {
                    status: 200,
                    message: "Persona Sin Datos"
                }
                res.status(200);
                res.json(resp);
            }
        } else if (logOk.status == 210) {
            let resp = {
                status: 210,
                message: "Debe actualizar su clave"
            }
            res.status(200);
            res.json(resp);
        }  else if (logOk.status == 220) {
            let resp = {
                status: 220,
                message: "Debe actualizar su clave - Presione Recuperar Clave"
            }
            res.status(200);
            res.json(resp);
        }  else if (logOk.status == 307) {
            let resp = {
                status: 220,
                message: "Clave provisoria expirada - Presione Recuperar Clave"
            }
            res.status(200);
            res.json(resp);
        } else if (logOk.status == 310 || logOk.status == 315) {
            let resp = {
                status: 400,
                message: "Usted se encuentra inactivo/bloqueado <br> Escriba a bienestar@interior.gov.cl"
            }
            res.status(200);
            res.json(resp);       
        } else {
            let resp = {
                status: 400,
                message: "Run/Clave incorrectos"
            }
            return res.status(200).send(resp)
        }
    } catch (err) {
        console.error("loginCv: " + err);
        res.status(500).send({ message: "Error al realizar Login OneReg" });
    }
}

async function createOneReg(req, res) {
    var idapp     = '';

    if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
        idapp = config.IDAPP_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        idapp = config.IDAPP_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        idapp = config.IDAPP_PROD;
    }

    try {
        let runSplit = req.body.unumDoc.split("-");
        let datos = {
            run: Number(runSplit[0]),
            dv: runSplit[1],
            numDoc: Number(req.body.uidPais) == 152 ? '' : req.body.unumDoc,
            idPais: Number(req.body.uidPais),
            direcciones:{
                idcomuna1: req.body.ucodComuna,
                domicilio1: req.body.udomicilio,
                idcomuna2: (req.body.ucodComunaLaboral == 0 ? null: req.body.ucodComunaLaboral),
                domicilio2: req.body.udomicilioLaboral
            }
        }

        let dom = {
            run: runSplit[0],
            numDoc: Number(req.body.uidPais) == 152 ? '' : req.body.unumDoc,
            idPais: Number(req.body.uidPais)
        }

        let create = {
            rut: datos.run,
            dv: datos.dv.toUpperCase(),
            serie: req.body.unumSerie.toUpperCase(),
            numdoc: datos.numDoc.toUpperCase(),
            idpais: datos.idPais,
            fecexpdoc: req.body.ufecVenDoc,
            idapp:  Number(idapp),
            nombre: req.body.unombre.toUpperCase(),
            apellido1: req.body.uapellido1.toUpperCase(),
            apellido2: (req.body.uapellido2.toUpperCase() == undefined) ? '' : req.body.uapellido2.toUpperCase(),
            email: req.body.uemail.toUpperCase(),
            genero: req.body.ugenero,
            fecnac: req.body.ufecNac,
            domicilio: req.body.udomicilio,
            domiciliolaboral: req.body.udomicilioLaboral,
            codcomuna: datos.direcciones.idcomuna1,
            codcomunalaboral: datos.direcciones.idcomuna2,
            iptran: req.body.uipTran
        }

        //console.log(create);
        var resultado = await helpersOneReg.createOneReg(req,create);        

        if (resultado.status == 200) {            
            let resp = {
                status: 200,
                message: "Registro exitoso"
            }
            res.status(200);
            res.json(resp);

        } else if (resultado.status == 303) {
            let resp = {
                status: 303,
                message: "Usuario ya se encuentra registrado"
            }
            res.status(200);
            res.json(resp);
        } else {
            //console.log("registro error " + JSON.stringify(resultado));
            res.status(400).send({ status: 400, messageError: resultado.message })
        }
    } catch (err) {
        console.error("onekey_register: " + err);
        res.status(500).send({ message: "Error interno del servidor en el registro OneReg" });
    }
}

async function restoreOneReg(req, res) {
    var idapp     = '';

    if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
        idapp = config.IDAPP_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        idapp = config.IDAPP_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        idapp = config.IDAPP_PROD;
    }

    try {        
        let runSplit = req.body.unumDoc.split("-");
        let datosRest = {
            rut: Number(runSplit[0]),
            dv: runSplit[1],
            numdoc: '',
            idpais: 152,
            email: req.body.uemail,
            idapp: Number(idapp),
            iptran: req.body.uipTran
        }
        //console.log(datosRest);
        var restoreOk = await helpersOneReg.restoreOneReg(req, datosRest);

        if (restoreOk.status == 200) {
            let resp = {
                status: 200,
                message: "Operación exitosa"
            }
            res.status(200);
            res.json(resp);

        } else if (restoreOk.status == 310 || restoreOk.status == 315) {
            let resp = {
                status: 400,
                message: "Usted se encuentra inactivo/bloqueado <br> Escriba a comisaria.virtual@carabineros.cl"
            }
            res.status(200);
            res.json(resp);       
        
        
        } else {
            let resp = {
                status: 400,
                message: "Run/Correo incorrectos"
            }
            return res.status(200).send(resp)
        }
    } catch (err) {
        console.error("recuperarCv: " + err);
        res.status(500).send({ message: "Error al Recuperar Clave" });
    }
}

async function updateOneReg(req, res) {
    var idapp     = '';

    if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
        idapp = config.IDAPP_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        idapp = config.IDAPP_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        idapp = config.IDAPP_PROD;
    }

    try {
        let runSplit = req.body.unumDoc.split("-");
        let datosRec = {
            rut: Number(runSplit[0]),
            dv: runSplit[1],
            numdoc: '',
            idpais: 152,
            codprov: req.body.ucodProv,
            password: req.body.upassword,
            email: req.body.uemail,
            idapp: Number(idapp),
            iptran: req.body.uipTran
        }

        var updateOk = await helpersOneReg.updateOneReg(req, datosRec);

        if (updateOk.status == 200) {
            let resp = {
                status: 200,
                message: "Operación exitosa"
            }
            res.status(200);
            res.json(resp);

        } else {
            let resp = {
                status: 400,
                message: "Error en actualizar clave"
            }
            return res.status(200).send(resp)
        }
    } catch (err) {
        //console.log("error en updateCv " + err);
        res.status(500).send({ message: "Error interno del servidor en Actualizar Clave" });
    }
}

async function loginLdap(req,res){

    const { uipTran, uusername, upassword } = req.body;

    if (uipTran) {       
        try {
            let resultado= await helpersLdap.loginLdap(req);
            if (resultado.status==200){
                let payload = await usuarioModel.leeUsuario({idUsuario:null,idAutoridad:null,apUno:null,apDos:null,nombre:null,
                                                             rut:null,dv:null,email:null,username:req.body.uusername,vigente:null}); 
                if (payload.status==200){
                    if (payload.usuario[0].vigente=='S'){                     
                        let salida = {
                            status :200,
                            message:payload.message,
                            token:service.createToken({rut:req.body.uusername,ipTran:req.body.uipTran,origin:req.get('origin')}),
                            usuario:payload.usuario
                        }
                        res.status(200).send(salida);   
                    }else{
                        res.status(200).send({status:201, message: 'Usuario No Vigente '});
                    }
                }else if (payload.status==400){
                    res.status(200).send({status:202, message: 'Usuario No Existe en Sistema '});
                }else{
                    res.status(200).send({status:payload.status, message: payload.message});
                }
            }else{
                res.status(200).send({status:203, message: 'Usuario/Clave Incorrecta'});
            }
        } catch (err) {
            return res.status(400).send({ message: "Error interno de Ldap" }+err);  
        }   
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}  

const leeLdap = async (req, res) => {
    let resp;

    const { uipTran, uuser } = req.body

    if (uipTran) {
        try{
            if (uuser && uuser.length>=3) {
                resp = await helpersLdap.leeLdap(req);
            }else{
                resp={
                    status:300,
                    meesage:'El término de búsqueda debe tener al menos 3 caracteres!'
                }
            }    
            return res.status(200).json(resp);
        } catch (err) {
            console.error("Error en controller/leeLdap: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeLdap"+err })            
        }
    } else {
        console.error("Error en controller/ldap: " + err);
        res.status(400).send({status: 400, message: 'error, cuerpo vacio' });
    }
}

async function datosRegCivil(req, res){
    let resp;
    if (req.body.uipTran) {
        try{
            // let rutEnt = (req.body.numDoc).split("-");     
            // let rut = rutEnt[0];
            // let dv  = rutEnt[1].toUpperCase();
            // console.log("Consulta SRCEI -> " + rutEnt[0]);     
            let rut = req.body.urut;
            let dv  = req.body.udv;
            let respuesta = await helpersExternalDeps.datosRegCivil(rut, dv);
    
            // if (respuesta.obj.fechaDefuncion=='0000-00-00'){
            //     resp = {
            //         status : 200,
            //         message: "Persona Viva"
            //     }
            // }else{
            //     resp = {
            //         status : 201,
            //         message: "Persona Fallecida "+respuesta.obj.fechaDefuncion
            //     }
            // }
            // res.status(200).send(resp);
            res.status(200).send(respuesta);
        } catch(error){
            console.log('auth-controller/datosRegCivil '+error);
            res.status(500).send({message: " Momentáneamente no disponible, intente más tarde."});
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

module.exports = {
    loginCu,
    claveUnica,
    loginOneReg,
    createOneReg,
    restoreOneReg,
    updateOneReg,
    loginLdap,
    leeLdap,
    datosRegCivil
};