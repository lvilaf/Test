'use-strict';
const tablaBaseModel = require('../models/tablaBase.model');
const loginModel = require('../models/usuario.model');

async function leeTabAntecedente(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'leeTabAntecedente',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabAntecedente: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabAntecedente" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function grabaTabAntecedente(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabAntecedente',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabAntecedente: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabAntecedente" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabAntecedente(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabAntecedente',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabAntecedente: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabAntecedente" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabArticulo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo      :'leeTabArticulo',
            id        :req.body.uid,
            glosa     :req.body.uglosa,
            vigente   :req.body.uvigente,
            ipTran    :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabArticulo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabArticulo" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabArticulo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabArticulo',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabArticulo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabArticulo" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabArticulo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabArticulo',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabArticulo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabArticulo" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabAutoridad(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'leeTabAutoridad',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabAutoridad: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabAutoridad" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function grabaTabAutoridad(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabAutoridad',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabAutoridad: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabAutoridad" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabAutoridad(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabAutoridad',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabAutoridad: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabAutoridad" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabCalidad(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabCalidad',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabCalidad: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabCalidad" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabCalidad(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabCalidad',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabCalidad: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabCalidad" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabCalidad(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabCalidad',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabCalidad: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabCalidad" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabCargo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabCargo',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            tipoP  :req.body.utipo,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabCargo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabCargo" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabCargo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabCargo',
            glosa      :req.body.uglosa,
            tipoP      :req.body.utipo,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabCargo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabCargo" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabCargo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabCargo',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            tipoP      :req.body.utipo,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabCargo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabCargo" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabEspecial(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabEspecial',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            tipoP  :req.body.utipo,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabEspecial: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabEspecial" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabEspecial(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabEspecial',
            glosa      :req.body.uglosa,
            tipoP      :req.body.utipo,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabEspecial: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabEspecial" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabEspecial(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabEspecial',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            tipoP      :req.body.utipo,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabEspecial: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabEspecial" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabMateria(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabMateria',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabMateria: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabMateria" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabMateria(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabMateria',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabMateria: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabMateria" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabMateria(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabMateria',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabMateria: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabMateria" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabMotivo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabMotivo',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabMotivo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabMotivo" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabMotivo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabMotivo',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabMotivo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabMotivo" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabMotivo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabMotivo',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabMotivo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabMotivo" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabPerfil(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabPerfil',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabPerfil: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabPerfil" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabPerfil(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabPerfil',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabPerfil: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabPerfil" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabPerfil(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabPerfil',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabPerfil: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabPerfil" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabPlantilla(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :"leeTabPlantilla",
            id     :req.body.uid,
            nombre :req.body.unombre,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabPlantilla: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabPlantilla" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabPlantilla(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabPlantilla',
            nombre     :req.body.unombre,
            asunto     :req.body.uasunto,
            cuerpo     :req.body.ucuerpo,
            remitente  :req.body.uremitente,
            obs        :req.body.uobs,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabPlantilla: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabPlantilla" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabPlantilla(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabPlantilla',
            id         :req.body.uid,
            nombre     :req.body.unombre,
            asunto     :req.body.uasunto,
            cuerpo     :req.body.ucuerpo,
            remitente  :req.body.uremitente,
            obs        :req.body.uobs,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabPlantilla: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabPlantilla" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}
/*
async function leeTabProcedencia(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabProcedencia',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabProcedencia: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabProcedencia" });
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabProcedencia(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabProcedencia',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabProcedencia: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabProcedencia" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabProcedencia(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabProcedencia',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabProcedencia: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabProcedencia" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}
*/
async function leeTabRegProvCom(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let v_idTipo;
        if       (req.body.uidTipo=='R'){
            v_idTipo=2;
        }else if (req.body.uidTipo=='P'){
            v_idTipo=3;
        }else if (req.body.uidTipo=='C'){
            v_idTipo=4;
        }else{
            v_idTipo=req.body.uidTipo;
        }
        let parametro = {
            tipo   :"leeTabRegProvCom",
            id     :req.body.uid,
            idPadre:req.body.uidPadre,
            idTipo :v_idTipo,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabRegProvCom: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabRegProvCom" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function leeTabTipo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabTipo',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabTipo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabTipo" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabTipo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabTipo',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabTipo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabTipo" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabTipo(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabTipo',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabTipo: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabTipo" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabTipoAgr(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabTipoAgr',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabTipoAgr: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabTipoAgr" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabTipoAgr(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabTipoAgr',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabTipoAgr: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabTipoAgr" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabTipoAgr(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabTipoAgr',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabTipoAgr: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabTipoAgr" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabTipoDir(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabTipoDir',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabTipoDir: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabTipoDir" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabTipoDir(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabTipoDir',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabTipoDir: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabTipoDir" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabTipoDir(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabTipoDir',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabTipoDir: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabTipoDir" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabTipoDoc(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'leeTabTipoDoc',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabTipoDoc: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabTipoDoc" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function grabaTabTipoDoc(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabTipoDoc',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabTipoDoc: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabTipoDoc" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabTipoDoc(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabTipoDoc',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabTipoDoc: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabTipoDoc" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabTipoSol(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabTipoSol',
            id     :req.body.uid,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabTipoSol: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabTipoSol" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabTipoSol(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabTipoSol',
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabTipoSol: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabTipoSol" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabTipoSol(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabTipoSol',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabTipoSol: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabTipoSol" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabTipoTra(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'leeTabTipoTra',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            cierre     :req.body.ucierre,
            vigente    :req.body.uvigente,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabTipoTra: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabTipoTra" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabTipoTra(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabTipoTra',
            glosa      :req.body.uglosa,
            cierre     :req.body.ucierre,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabTipoTra: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabTipoTra" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabTipoTra(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabTipoTra',
            id         :req.body.uid,
            glosa      :req.body.uglosa,
            cierre     :req.body.ucierre,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabTipoTra: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabTipoTra" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function leeTabTramite(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo   :'leeTabTramite',
            id     :req.body.uid,
            idTipo :req.body.uidTipo,
            glosa  :req.body.uglosa,
            vigente:req.body.uvigente,
            ipTran :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.leeTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeTabTramite: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeTabTramite" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaTabTramite(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'grabaTabTramite',
            idTipo     :req.body.idTipo,
            glosa      :req.body.uglosa,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.grabaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/grabaTabTramite: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaTabTramite" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

async function actualizaTabTramite(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            tipo       :'actualizaTabTramite',
            id         :req.body.uid,
            idTipo     :req.body.uidTipo,
            glosa      :req.body.uglosa,
            vigente    :req.body.uvigente,
            idUsuario  :req.body.uidUsuario,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await tablaBaseModel.actualizaTablaBase(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaTabTramite: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaTabTramite" })
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

module.exports = {
    leeTabAntecedente,
    grabaTabAntecedente,
    actualizaTabAntecedente,
    leeTabArticulo,
    grabaTabArticulo,
    actualizaTabArticulo,
    leeTabAutoridad,
    grabaTabAutoridad,
    actualizaTabAutoridad,
    leeTabCalidad,
    grabaTabCalidad,
    actualizaTabCalidad,
    leeTabCargo,
    grabaTabCargo,
    actualizaTabCargo,
    leeTabEspecial,
    grabaTabEspecial,
    actualizaTabEspecial,
    leeTabMateria,
    grabaTabMateria,
    actualizaTabMateria,
    leeTabMotivo,
    grabaTabMotivo,
    actualizaTabMotivo,
    leeTabPerfil,
    grabaTabPerfil,
    actualizaTabPerfil,
    leeTabPlantilla,
    grabaTabPlantilla,
    actualizaTabPlantilla,
    leeTabRegProvCom,
    leeTabTipo,
    grabaTabTipo,
    actualizaTabTipo,
    leeTabTipoAgr,
    grabaTabTipoAgr,
    actualizaTabTipoAgr,
    leeTabTipoDir,
    grabaTabTipoDir,
    actualizaTabTipoDir,
    leeTabTipoDoc,
    grabaTabTipoDoc,
    actualizaTabTipoDoc,
    leeTabTipoSol,
    grabaTabTipoSol,
    actualizaTabTipoSol,
    leeTabTipoTra,
    grabaTabTipoTra,
    actualizaTabTipoTra,
    leeTabTramite,
    grabaTabTramite,
    actualizaTabTramite
};