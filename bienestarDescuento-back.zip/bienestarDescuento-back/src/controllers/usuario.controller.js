'use-strict';
const usuarioModel = require('../models/usuario.model');

async function leeUsuario(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            idUsuario  :req.body.uidUsuario,
            idAutoridad:req.body.uidAutoridad,
            rut        :req.body.urut,
            dv         :req.body.udv,
            apUno      :req.body.uapUno,
            apDos      :req.body.uapDos,
            nombre     :req.body.unombre,
            email      :req.body.uemail,
            username   :req.body.uusername,
            vigente    :req.body.uvigente,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await usuarioModel.leeUsuario(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeUsuario: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeUsuario "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaUsuario(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            idAutoridad:req.body.uidAutoridad,
            rut        :req.body.urut,
            dv         :req.body.udv,
            apUno      :req.body.uapUno,
            apDos      :req.body.uapDos,
            nombre     :req.body.unombre,
            email      :req.body.uemail,
            username   :req.body.uusername,
            obs        :req.body.uobs,
            idUsuarioP :req.body.uidUsuarioP,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await usuarioModel.grabaUsuario(parametro);
            res.status(200).json(respuesta);
        } catch (err) {
            console.error("Error en controller/grabaUsuario: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaUsuario "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function actualizaUsuario(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            idUsuario  :req.body.uidUsuario,
            idAutoridad:req.body.uidAutoridad,
            rut        :req.body.urut,
            dv         :req.body.udv,
            apUno      :req.body.uapUno,
            apDos      :req.body.uapDos,
            nombre     :req.body.unombre,
            email      :req.body.uemail,
            username   :req.body.uusername,
            obs        :req.body.uobs,
            vigente    :req.body.uvigente,
            idUsuarioP :req.body.uidUsuarioP,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await usuarioModel.actualizaUsuario(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/actualizaUsuario: " + err);
            res.status(400).send({status: 501, message: "Error en controller/actualizaUsuario "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function borraUsuario(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            idUsuario :req.body.uidUsuario,
            idUsuarioP:req.body.uidUsuarioP,
            ipTran    :req.body.uipTran
        }
        try {
            respuesta = await usuarioModel.borraUsuario(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/borraUsuario: " + err);
            res.status(400).send({status: 501, message: "Error en controller/borraUsuario "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function leePermiso(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            idUsuario :req.body.uidUsuario,
            idPerfil  :req.body.uidPerfil,
            fecPermiso:req.body.ufecPermiso,
            ipTran    :req.body.uipTran
        }
        try {
            respuesta = await usuarioModel.leePermiso(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leePermiso: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leePermiso "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function grabaPermiso(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            idUsuario :req.body.uidUsuario,
            idPerfil  :req.body.uidPerfil,
            fecPermiso:req.body.ufecPermiso,
            idUsuarioP:req.body.uidUsuarioP,
            ipTran    :req.body.uipTran
        }
        try {
            respuesta = await usuarioModel.grabaPermiso(parametro);
            res.status(200).json(respuesta);
        } catch (err) {
            console.error("Error en controller/grabaPermiso: " + err);
            res.status(400).send({status: 501, message: "Error en controller/grabaPermiso "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

async function borraPermiso(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            idUsuario :req.body.uidUsuario,
            idPerfil  :req.body.uidPerfil,
            idUsuarioP:req.body.uidUsuarioP,
            ipTran    :req.body.uipTran
        }
        try {
            respuesta = await usuarioModel.borraPermiso(parametro);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/borraPermiso: " + err);
            res.status(400).send({status: 501, message: "Error en controller/borraPermiso "+err })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }
}

module.exports = {
    leeUsuario,
    grabaUsuario,
    actualizaUsuario,
    borraUsuario,
    leePermiso,
    grabaPermiso,
    borraPermiso
};