'use-strict';
const utilModel = require('../models/util.model');

async function getVersion(req,res){
    try {
        respuesta = await utilModel.getVersion();

        if (respuesta.status == 200) {
            res.status(200).json(respuesta);
        }else{
            res.status(200).json(respuesta);
        }
    } catch (err) {
        console.error("Error en controller/getVersion: " + err);
        res.status(400).send({status: 501, message: "Error en controller/getVersion" })            
    }
}

async function getVersionDB(req,res){
    try {
        respuesta = await utilModel.getVersionDB('C');

        if (respuesta.status == 200) {
            res.status(200).json(respuesta);
        }else{
            res.status(200).json(respuesta);
        }
    } catch (err) {
        console.error("Error en controller/getVersionDB: " + err);
        res.status(400).send({status: 501, message: "Error en controller/getVersionDB" })            
    }
}

async function leeVar(req, res) {
    let respuesta;
    if (req.body.uipTran) {
        let parametro = {
            var        :req.body.uvar,
            ipTran     :req.body.uipTran
        }
        try {
            respuesta = await utilModel.leeVar(req.body.uvar);

            if (respuesta.status == 200) {
                res.status(200).json(respuesta);
            }else{
                res.status(200).json(respuesta);
            }
        } catch (err) {
            console.error("Error en controller/leeVar: " + err);
            res.status(400).send({status: 501, message: "Error en controller/leeVar" })            
        }
    } else {
        res.status(400).send({ message: 'error, cuerpo vacio' });
    }        
}

module.exports = {
    getVersion,
    getVersionDB,
    leeVar
};