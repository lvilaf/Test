const ftp = require("basic-ftp");
const ftp2 = require("ftp");
const config = require("../../config/config");
const path = require("path");
const mime = require('mime-types');
const FormData = require('form-data');
var fs = require('fs');
const { Writable } = require('stream');
const utilModel = require('../models/util.model');
//const buffer = require('buffer');

async function subirAlfresco(req, ano, mes, idAutoridad, temp, files) {
    const client = new ftp.Client();
    client.ftp.verbose = false;
    let v_sta=200;
    let v_msg='';

    let v_host;
    let v_pass;
    if       (req.get('origin') == config.ORIGIN_AUTH_DESA){
        v_host      = config.REPO_HOST_DESA;
        v_pass      = config.REPO_PASS_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        v_host      = config.REPO_HOST_TEST;
        v_pass      = config.REPO_PASS_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        v_host      = config.REPO_HOST_PROD;
        v_pass      = config.REPO_PASS_PROD;
    }else{
        res.status(400).send({status:400,message:'Origin NO Autorizado '+req.get('origin')});
    }

    try {
        await client.access({
            host: v_host,
            user: process.env.REPO_USER,
            password: v_pass,
            secure: false
        });
      
        temp = process.env.REPO_HOME + temp;
        let ruta = ano+'_'+mes+'_'+idAutoridad;
        
        await client.ensureDir(temp+ruta+'/');

        // await client.clearWorkingDir(temp+ruta+'/');
        
        await client.uploadFrom(files.archivo.filepath, temp+ruta+'/'+files.archivo.originalFilename);

    } catch (err) {
        v_sta=400;
        v_msg="Ocurrió un error en Alfresco al crear el archivo "+archivo+" "+err;
        // console.log(err);
    }
    client.close();

    let estado={
        status :v_sta,
        message:v_msg
    }    
    return estado;
}

async function bajarAlfresco(req,data) {
    const client = new ftp.Client();
    client.ftp.verbose = false;
    let v_sta=200;
    let v_msg='';
    let v_fechaHora=((await utilModel.leeFechaHora()).message).replace(' ','');
    let replacer = new RegExp('/','g');
    v_fechaHora=v_fechaHora.replace(replacer,'');
    replacer = new RegExp(':','g');
    v_fechaHora=v_fechaHora.replace(replacer,'');

    let v_host;
    let v_pass;
    if       (req.get('origin') == config.ORIGIN_AUTH_DESA){
        v_host      = config.REPO_HOST_DESA;
        v_pass      = config.REPO_PASS_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        v_host      = config.REPO_HOST_TEST;
        v_pass      = config.REPO_PASS_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        v_host      = config.REPO_HOST_PROD;
        v_pass      = config.REPO_PASS_PROD;
    }else{
        res.status(400).send({status:400,message:'Origin NO Autorizado '+req.get('origin')});
    }
    try {
        await client.access({
            host: v_host,
            user: process.env.REPO_USER,
            password: v_pass,
            secure: false
        });

        let ruta = process.env.REPO_HOME + data.ano + '/' + data.mes + '/' + data.idAutoridad + '/';
        await client.ensureDir(ruta);
        let lst = [];
        lst = await client.list(ruta);
        let v_file = lst[0].name;
        
        let prueba=fs.createWriteStream('./'+data.ano+'_'+data.mes+'_'+data.idAutoridad+'_'+v_fechaHora+'_'+v_file);

        await client.downloadTo(prueba, ruta + v_file);

        let prueba3 = fs.readFileSync('./'+data.ano+'_'+data.mes+'_'+data.idAutoridad+'_'+v_fechaHora+'_'+v_file);

        fs.unlinkSync                ('./'+data.ano+'_'+data.mes+'_'+data.idAutoridad+'_'+v_fechaHora+'_'+v_file);

    } catch (err) {
        v_sta=400;
        v_msg="Ocurrió un error en Alfresco al bajar el archivo "+" "+err;
        // console.log(err);
    }
    client.close();
    return {status:v_sta,message:v_msg,obj:prueba3};
}

async function renombrarAlfresco(req, data) {
    const client = new ftp.Client();
    client.ftp.verbose = false;
    let ruta_tmp;
    let ruta_fin;
    let v_sta=400;
    let v_msg='';
    let v_file='';
    let v_ext;
    let v_lista='';
    let v_listaErr='';
    let tmp = data.ano+'_'+data.mes+'_'+data.idAutoridad;

    ruta_tmp= process.env.REPO_HOME + process.env.REPO_TEMP + tmp + '/';
    ruta_fin= process.env.REPO_HOME + data.ano + '/' + data.mes + '/' + data.idAutoridad + '/';

    let v_host;
    let v_pass;
    if       (req.get('origin') == config.ORIGIN_AUTH_DESA){
        v_host      = config.REPO_HOST_DESA;
        v_pass      = config.REPO_PASS_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        v_host      = config.REPO_HOST_TEST;
        v_pass      = config.REPO_PASS_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        v_host      = config.REPO_HOST_PROD;
        v_pass      = config.REPO_PASS_PROD;
    }else{
        res.status(400).send({status:400,message:'Origin NO Autorizado '+req.get('origin')});
    }
    try {
        await client.access({
            host: v_host,
            user: process.env.REPO_USER,
            password: v_pass,
            secure: false
        });
        v_msg="Error Alfresco - Directorio No Existe: "+ruta_tmp;
        let lst = [];
        lst = await client.list(ruta_tmp);
        if (lst.length==0){
            v_msg="Error Alfresco - Directorio Vacío: "+ruta_tmp;
            throw new Error();
        }else{
            v_msg="Error Alfresco - No Crea Directorio: "+ruta_fin;
            await client.ensureDir(ruta_fin);
            await client.clearWorkingDir(ruta_fin);
    
            v_msg="Error Alfresco - No Movió Archivos de TEMP ";
            for (let index = 0; index < lst.length; index++) {
    
                v_file = lst[index].name;
                v_ext  = path.extname(lst[index].name);

                await client.rename(ruta_tmp+v_file,ruta_fin+v_file);
                if (v_lista==''){
                    v_lista=v_file+'&#&'+v_ext;
                }else{
                    v_lista=v_lista+'&%&'+v_file+'&#&'+v_ext;
                }    
            }
        }
        v_sta=200;
        v_msg='';
        await client.removeDir(ruta_tmp,true); 
    } catch (err) {
        if (v_msg==''){
            v_msg="Error Alfresco "+err;    
        }
        v_lista='';
        try {
            await client.removeDir(ruta_fin,true); 
        } catch (error) {
        }
        try{
            await client.removeDir(ruta_tmp,true); 
        } catch (error) {
        }
    // console.log(err);
    }
    client.close();

    let estado={
        status   :v_sta,
        message  :v_msg,
        lista    :v_lista,
        listaErr :v_listaErr
    }
    return estado;
}

/*
async function renombrarAlfresco(req, data) {
    const client = new ftp.Client();
    client.ftp.verbose = false;
    let ruta_tmp;
    let ruta_fin;
    let v_sta=400;
    let v_msg='';
    let v_file='';
    let v_ext;
    let v_lista='';
    let v_listaErr='';
    let tmp = data.ano+'_'+data.mes+'_'+data.idAutoridad;

    ruta_tmp= process.env.REPO_HOME + process.env.REPO_TEMP + tmp + '/';
    ruta_fin= process.env.REPO_HOME + data.ano + '/' + data.mes + '/' + data.idAutoridad + '/';

    let v_host;
    let v_pass;
    if       (req.get('origin') == config.ORIGIN_AUTH_DESA){
        v_host      = config.REPO_HOST_DESA;
        v_pass      = config.REPO_PASS_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        v_host      = config.REPO_HOST_TEST;
        v_pass      = config.REPO_PASS_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        v_host      = config.REPO_HOST_PROD;
        v_pass      = config.REPO_PASS_PROD;
    }else{
        res.status(400).send({status:400,message:'Origin NO Autorizado '+req.get('origin')});
    }
    try {
        await client.access({
            host: v_host,
            user: process.env.REPO_USER,
            password: v_pass,
            secure: false
        });
        v_msg="Error Alfresco - Directorio No Existe: "+ruta_tmp;
        let lst = [];
        lst = await client.list(ruta_tmp);
        if (lst.length==0){
            v_msg="Error Alfresco - Directorio Vacío: "+ruta_tmp;
        }else{
            v_msg="Error Alfresco - No Crea Directorio: "+ruta_fin;
            await client.ensureDir(ruta_fin);
            await client.clearWorkingDir(ruta_fin);
    
            v_msg="Error Alfresco - No Movió Archivos de TEMP ";
            for (let index = 0; index < lst.length; index++) {
    
                v_file = lst[index].name;
                v_ext  = path.extname(lst[index].name);

                try {
                    await client.rename(ruta_tmp+v_file,ruta_fin+v_file);
                    if (v_lista==''){
                        v_lista=v_file+'&#&'+v_ext;
                    }else{
                        v_lista=v_lista+'&%&'+v_file+'&#&'+v_ext;
                    }    
                } catch (error) {
                    if (v_listaErr==''){
                        v_listaErr=v_file;
                    }else{
                        v_listaErr=v_listaErr+','+v_file;
                    }            
                }
            }
        }
        await client.removeDir(ruta_tmp,true); 
    } catch (err) {
        if (v_msg==''){
            v_msg="Error Alfresco "+err;    
        }
    // console.log(err);
    }
    client.close();

    let estado={
        status   :v_sta,
        message  :v_msg,
        lista    :v_lista,
        listaErr :v_listaErr
    }
    return estado;
}
*/
async function borrarAlfresco(req, data) {
    const client = new ftp.Client();
    client.ftp.verbose = false;
    let ruta_fin;
    let v_sta=200;
    let v_msg='';
    let v_file;
    let v_ext;

    let v_host;
    let v_pass;
    if       (req.get('origin') == config.ORIGIN_AUTH_DESA){
        v_host      = config.REPO_HOST_DESA;
        v_pass      = config.REPO_PASS_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        v_host      = config.REPO_HOST_TEST;
        v_pass      = config.REPO_PASS_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        v_host      = config.REPO_HOST_PROD;
        v_pass      = config.REPO_PASS_PROD;
    }else{
        res.status(400).send({status:400,message:'Origin NO Autorizado '+req.get('origin')});
    }
    try {
        await client.access({
            host: v_host,
            user: process.env.REPO_USER,
            password: v_pass,
            secure: false
        });

        ruta_fin= process.env.REPO_HOME + data.ano + '/' + data.mes + '/' + data.idAutoridad + '/' + data.fileName;
        // await client.ensureDir(ruta_fin);
        // let lst = [];
        // lst = await client.list(ruta_fin);
        // let v_file = lst[0].name;

        await client.remove(ruta_fin);

    } catch (err) {
        v_sta=400;
        v_msg="Ocurrió un error en Alfresco al borrar el archivo "+ruta_fin+" "+err;
        console.log(err);
    }
    client.close();
    
    let estado={
        status   :v_sta,
        message  :v_msg
    }
    return estado;
}

module.exports = {
    subirAlfresco,
    bajarAlfresco,
    renombrarAlfresco,
    borrarAlfresco
};