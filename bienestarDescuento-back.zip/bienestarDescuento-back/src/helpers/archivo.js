
const fs = require('fs');

async function existeArchivo(arch) {


    //console.log("existeArchivo");

    try{
        if(fs.existsSync(arch)) {
            return 1;
        } else {
            return 0;
        }
    } catch(err){
        console.error("existeArchivo : " + err);
    }

}

async function leerArchivo2(nombreArchivo) {


    // console.log("leerArchivo");
    try {
        var h = JSON.parse(fs.readFileSync(nombreArchivo, 'utf-8'));
        return h;
    
    } catch(err){
        console.log("error en leerArchivo " + err);
        res.status(500).send({message:"Error interno del servidor"});
    }
}

async function leerArchivo3(nombreArchivo) {

    var BinaryFile = require('binary-file');
 
    var myBinaryFile = new BinaryFile(nombreArchivo, 'r');

  try {
    await myBinaryFile.open();
    console.log('File opened');
    const stringLength = await myBinaryFile.readUInt64();
   // const string = await myBinaryFile.readString(stringLength);
    // console.log(`File read: ${string}`);

    await myBinaryFile.close();

    return myBinaryFile;
    
    console.log('File closed');
  } catch (err) {
    console.log(`There was an error: ${err}`);
  }
}
async function leerArchivo(nombreArchivo) {

    var h = JSON.parse(fs.readFileSync(nombreArchivo, 'utf-8'));

    return h;

}


async function escribirArchivo(nombreArchivo,informacion) {

    fs.writeFile(nombreArchivo, informacion, function(err) {
        if(err) {
            console.error("escribirArchivo: " + err);
            return err;
        } else {
            comprimirArchivo(nombreArchivo);
        }
        //console.log("El archivo fue grabado");
    }); 

}


async function comprimirArchivo(nombreArchivo) {

    var zlib = require('zlib');
    var gzip = zlib.createGzip();
    var fs = require('fs');
    var inp = fs.createReadStream(nombreArchivo);
    var out = fs.createWriteStream(nombreArchivo + '.gz');
    
    inp.pipe(gzip).pipe(out);

}

function getIndexFromName(prefix, name) {
    var length = prefix.length;
    var index = name.indexOf(prefix + '-');

    if (index < 0)
        return -1;

    var indexPart = name.substring(length + 1); 
    if (indexPart.indexOf('.') > 0)
        indexPart = indexPart.substring(name.indexOf('.'));

    if (Number(indexPart) != NaN)
        return Number(indexPart);


    return -1;
}

async function getLastMasterFileIndex(repositoryPath, fileNamePrefix) {
    var maxIndex = -1;

    fs.readdirSync(repositoryPath).forEach(file => {
        var index = getIndexFromName(fileNamePrefix, file);

        if (index >= 0) {
            if (index > maxIndex)
                maxIndex = index;
        }
    });

    return maxIndex;
}

async function renameFile(pathName, suffix){
    fs.rename(pathName, pathName + "_" + suffix, function(err) {
        if ( err ) console.error('renameFile: ' + err + " idPermiso " + suffix);
    });
}

///////////////////////////////////////////////////////////////////////////////////

/*----------------------------------------------------------------------------------------*/
async function calcularSumaFunc(data, propiedad){
    return data.reduce((total, fila) => {
      const valor = parseFloat(fila[propiedad])
      if (!isNaN(valor)) {
        return total + valor
      } else {
        return total
      }
    }, 0)
  }
  
  /*----------------------------------------------------------------------------------------*/
  async function checkSumFunc(sum, buffer){
    for (let i = 0; i < buffer.length; i++) {
      sum = (sum >> 1) + ((sum & 1) << 15)
      sum += buffer.charCodeAt(i) & 0xff
      sum &= 0xffff
    }
    return sum
  }
  
  /*----------------------------------------------------------------------------------------*/
  async function seleccionExcel(req){
    /* seleccion del archivo */
    const hojaExcel = XLSX.read(req.file.buffer, { type: 'buffer' })
    const hojaNombre = hojaExcel.SheetNames[0]
    const hoja = hojaExcel.Sheets[hojaNombre]
  
    //si envia una hoja de excel en blanco
    if (!hoja || !hoja['!ref']) {
      return []
    }
  
    //limite de filas dinamico
    const ultimaFila = hoja['!ref'].split(':').pop().match(/\d+/)[0]
    const rango = { s: { c: 0, r: 7 }, e: { c: 16, r: ultimaFila } }
  
    /* creacion del json - un objeto equivaldrá a una fila  */
    const jsonData = XLSX.utils
      .sheet_to_json(hoja, {
        range: rango,
        header: 1,
        blankrows: false,
      })
      .filter((value) =>
        value.some(
          (celda, indice) => XLSX.utils.encode_col(indice) && celda !== ''
        )
      )
  
    /* verificacion de si existen valores indefinidos */
    const hasUndefinedValue = jsonData.some((value) => {
      return (
        value[10] === undefined ||
        value[1] === undefined ||
        value[2] === undefined ||
        value[3] === undefined ||
        value[5] === undefined ||
        value[6] === undefined ||
        value[7] === undefined ||
        value[8] === undefined ||
        value[14] === undefined ||
        value[16] === undefined
      )
    })
  
    //Si hay al menos una valor indefinido
    if (hasUndefinedValue) {
      return []
    }
  
    /* definicion de una clave (antiguamente columna) a cada valor (antiguamente fila) obtenido del json  */
    const formattedData = jsonData.map((value) => {
      //Formato fecha
      const partesFecha = value[14].split('/')
      const dia = partesFecha[0]
      const mes = partesFecha[1] - 1 // (enero es 0)
      const anio = partesFecha[2]
      const fecha = new Date(anio, mes, dia)
      const fechaFormateada = fecha.toISOString().slice(0, 10)
  
      return {
        codigo_servicio: value[10].toString(),
        codigo_descuento: value[1].toString(),
        glosa_descuento: value[2],
        rut: value[3].toString(),
        monto_informado: value[5].toString(),
        monto_descontado: value[6].toString(),
        monto_no_pagado: value[7].toString(),
        nro_cheque: value[8].toString(),
        fecha_cheque: fechaFormateada,
        monto_cheque: value[16].toString(),
      }
    })
    //en este punto es un objeto con su par clave-valor
    return formattedData
  }


async function formatoXML(req) {
    //extraemos el objeto generado a partir del excel que se enviara
    const formattedData = seleccionExcel(req)
  
    /* calculos */
    const total_informado = calcularSumaFunc(
      formattedData,
      'monto_informado'
    ).toString()
    console.log(`La suma de todos los "total_informado" es: ${total_informado}`)
  
    const total_descontado = calcularSumaFunc(
      formattedData,
      'monto_descontado'
    ).toString()
    console.log(`La suma de todos los "total_descontado" es: ${total_descontado}`)
  
    const total_no_pagado = calcularSumaFunc(
      formattedData,
      'monto_no_pagado'
    ).toString()
    console.log(`La suma de todos los "total_no_pagado" es: ${total_no_pagado}`)
  
    const nro_registros = formattedData.length.toString()
    console.log(`El total de nro_registros es: ${nro_registros}`)
  
    let checksum = 0
  
    formattedData.forEach((data) => {
      checksum = checkSumFunc(checksum, data.codigo_servicio)
      checksum = checkSumFunc(checksum, data.codigo_descuento)
      checksum = checkSumFunc(checksum, data.glosa_descuento)
      checksum = checkSumFunc(checksum, data.rut)
      checksum = checkSumFunc(checksum, data.monto_informado)
      checksum = checkSumFunc(checksum, data.monto_descontado)
      checksum = checkSumFunc(checksum, data.monto_no_pagado)
      checksum = checkSumFunc(checksum, data.nro_cheque)
      checksum = checkSumFunc(checksum, data.fecha_cheque)
      checksum = checkSumFunc(checksum, data.monto_cheque)
    })
    console.log(`El checksum de los datos es: ${checksum}`)
  
    /* estructura que tendra el xml */
  
    //etiqueta <xml>
    const options = {
      rootName: 'bienestar',
      xmldec: {
        version: '1.0',
        encoding: 'UTF-8',
      },
    }
    const xmlOptionsOuput = `<?xml version="${options.xmldec.version}" encoding="${options.xmldec.encoding}"?>`
  
    //etiqueta <registro> con los calculos obtenidos
    const xmlString = formattedData
      .map((data) => {
        return `<registro codigo_servicio="${data.codigo_servicio}" codigo_descuento="${data.codigo_descuento}" \
  glosa_descuento="${data.glosa_descuento}" rut="${data.rut}" monto_informado="${data.monto_informado}" \
  monto_descontado="${data.monto_descontado}" monto_no_pagado="${data.monto_no_pagado}" 
  nro_cheque="${data.nro_cheque}" fecha_cheque="${data.fecha_cheque}" monto_cheque="${data.monto_cheque}"/>`
      })
      .join('\n')
  
    //estructura de etiqueta <bienestar> que envolverá a etiqueta <registro>
    const bienestarOptionsOuput = `<bienestar total_informado="${total_informado}" total_descontado="${total_descontado}"\
    total_no_pagado="${total_no_pagado}" nro_registros="${nro_registros}" checksum="${checksum}">
  ${xmlString}
  </bienestar>`
  
    //
    const xmlOutput = `${xmlOptionsOuput}\n${bienestarOptionsOuput}`
    return xmlOutput
  }


module.exports = {
    existeArchivo,
    escribirArchivo,
    leerArchivo,
    getLastMasterFileIndex,
    renameFile,
    formatoXML
};