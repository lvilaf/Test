const request = require('request');
const config = require('../../config/config');

exports.validarCaptcha = function(req, res, next){
//    console.log("captcha: ",req);

    var secret_key = '';

    if (req.headers.origin  == config.ORIGIN_AUTH_DESA){
        secret_key = config.SECRET_KEY_DESA;
    }else if (req.headers.origin == config.ORIGIN_AUTH_TEST){
        secret_key = config.SECRET_KEY_TEST;
    }else if (req.headers.origin == config.ORIGIN_AUTH_PROD){
        secret_key = config.SECRET_KEY_PROD;
    }else if (req.headers.origin == config.ORIGIN_AUTH_LOCAL){
        secret_key = config.SECRET_KEY_DESA;
    }
   
    const proxy = config.PROXY;
    var secret = '';
    secret = secret_key;
    const url = config.URI_CAPTCHA;

    var options = {
        proxy: proxy,
        uri: url + secret + '&response=' + req.body.urecaptcha,
        method: 'GET',
        headers: {
            Host: 'www.google.com'
        }
    };
    
// console.log(options);
    request(options, function (err, resp, body) {
        if(err){
           console.error('validarCaptcha:', err);
           res.json(err);
          } else {
            //console.log(body);
            var respuesta = JSON.parse(body);
            if(respuesta){
               
                if(req.headers.origin == config.ORIGIN_AUTH_PROD){
                    console.log(respuesta);
                    if(respuesta["score"] >= 0.4){
                        next();
                    } else {
                        //console.log("error captcha");
                        res.status(200).json({
                            status: 400,
                            success: false,
                            message: "error captcha"
                        });
                        // next();
                    }
                }else{
                    if(respuesta["score"] >= 0.1){
                        next();
                    } else {
                        //console.log("error captcha");
                        res.status(200).json({
                            status: 401,
                            success: false,
                            message: "error captcha"
                        });
                        // next();
                    }
                }
            }
         }
      });
}