const fetch = require("node-fetch");
const qs = require("querystring");
const utf8 = require('utf8');
const HttpProxyAgent = require('https-proxy-agent');
const config = require('../../config/config');
const { text } = require("body-parser");
const { restart } = require("nodemon");
const proxy = config.PROXY;

async function  obtieneAccessToken(req, code, CSRFToken) {
    var clientId = '';
    var redirectUri = '';
    var clientSecret = '';

    if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
        clientId    = config.CLIENT_ID_DESA;
        redirectUri = config.REDIRECT_URI_DESA;
        clientSecret= config.CLIENT_SECRET_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        clientId    = config.CLIENT_ID_TEST;
        redirectUri = config.REDIRECT_URI_TEST;
        clientSecret= config.CLIENT_SECRET_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        clientId    = config.CLIENT_ID_PROD;
        redirectUri = config.REDIRECT_URI_PROD;
        clientSecret= config.CLIENT_SECRET_PROD;
    }
    try{
        var url= config.CLAVEUNICA_REDIRECT + 'openid/token';
        let urlRedirect = utf8.encode(redirectUri);
        var datos = { 
            "client_id": clientId,
            "client_secret": clientSecret,
            "grant_type":"authorization_code",
            "code": code,
            "state": CSRFToken               
            };
        var query = qs.stringify(datos);
        query = query +'&redirect_uri='+ urlRedirect;
            
        return await fetch(url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
            body: query,
            timeout: 3000,
            agent: new HttpProxyAgent(proxy)  
            }).then(function(response){

                if(response.status == 200  ){
                    // if(!response.hasOwnProperty('access_token')) 
                    //     throw new Error("response no viene access_token :" + response.status );

                    return response.json().then(data => ({status:200,message:'',obj:data}));
                } else {
                    throw new Error("response diferente de 200 :" + response.statusText );
                }           
            }).catch((error) => { return ({status:400,message:"obtieneAccessToken: " + error}) });
    } catch(error) {
        throw error;
    }
}

async function obtieneDatos(accesstoken) {
    try{
        var url= config.CLAVEUNICA_REDIRECT + 'openid/userinfo/';
        return await fetch(url, {
            method: 'POST',
            headers: { 'Authorization': "Bearer " + accesstoken},
            timeout: 3000,
            agent: new HttpProxyAgent(proxy)  
        }).then(function(response){
            if(response.status == 200){
                return response.json().then(data => ({status:200,message:'',obj:data}));
            } else {
                throw new Error("response diferente de 200 " + response.status);
            }
        }).catch((error) => { return ({status:400,message:"obtieneDatos: " + error}) });
    } catch(error) {
        throw error;
    }
}

module.exports = {
    obtieneAccessToken,
    obtieneDatos
};
