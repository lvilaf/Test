const utilModel = require('../models/util.model');
const nodemailer = require('nodemailer');
const emailtemplate = require('email-templates');
const config = require('../../config/config');
async = require('async');

config.NODE_TLS_REJECT_UNAUTHORIZED = "0";

async function enviarCorreo(datos, idPlantilla, usuario, idSol) {
    let resul=0;
    let tit;
    let sol;
    let usu;
    let now   = new Date();
//    let day   = now.getDay();
//    let month = now.getMonth();
//    let year  = now.getFullYear();
//    let v_fecha = day+'/'+month+'/'+year;
    let v_fechaHora=((await utilModel.leeFechaHora()).message).split(' ');
    let v_fecha=v_fechaHora[0];

    var v_idTipoPerTit= parseInt((await utilModel.leeVar("id_tipoper_titular")).message);
    var v_idTipoPerSol= parseInt((await utilModel.leeVar("id_tipoper_solicitante")).message);
    var datosMail     = await utilModel.leeTabPlantilla(idPlantilla);

    try {

        for (let per of datos){
            if (per.idTipoPer==v_idTipoPerTit){
                tit={
                    nombre:(per.nombre == undefined) ? '' : per.nombre.toUpperCase(),
                    apUno :(per.apUno  == undefined) ? '' : per.apUno.toUpperCase(),
                    apDos :(per.apDos  == undefined) ? '' : per.apDos.toUpperCase(),
                    rut   :per.rut+'-'+per.dv,
                    email :per.email
                }
            }else if (per.idTipoPer==v_idTipoPerSol){
                sol={
                    nombre:(per.nombre == undefined) ? '' : per.nombre.toUpperCase(),
                    apUno :(per.apUno  == undefined) ? '' : per.apUno.toUpperCase(),
                    apDos :(per.apDos  == undefined) ? '' : per.apDos.toUpperCase(),
                    rut   :per.rut+'-'+per.dv,
                    email :per.email
                }
            }
        }
        if (usuario != null){
            usu = {
                nombre  :(usuario.usuario[0].nombre   == undefined) ? '' : usuario.usuario[0].nombre.toUpperCase(),
                apUno   :(usuario.usuario[0].apUno    == undefined) ? '' : usuario.usuario[0].apUno.toUpperCase(),
                apDos   :(usuario.usuario[0].apDos    == undefined) ? '' : usuario.usuario[0].apDos.toUpperCase(),
                email   : usuario.usuario[0].email,
                username:(usuario.usuario[0].username == undefined) ? '' : usuario.usuario[0].username.toUpperCase()
            }    
        }

        var body = datosMail.info[1];  //cuerpo

        const fechaSol     = /@{fechaSol}/gi;

        const nombreTit    = /@{nombreTit}/gi;
        const apellido1Tit = /@{apellido1Tit}/gi;
        const apellido2Tit = /@{apellido2Tit}/gi;
        const rutTit       = /@{rutTit}/gi;

        const nombreSol    = /@{nombreSol}/gi;
        const apellido1Sol = /@{apellido1Sol}/gi;
        const apellido2Sol = /@{apellido2Sol}/gi;
        const rutSol       = /@{rutSol}/gi;

        const nombre       = /@{nombre}/gi;
        const apUno        = /@{apUno}/gi;
        const apDos        = /@{apDos}/gi;
        const username     = /@{username}/gi;
        const idSolicitud  = /@{idSolicitud}/gi;

        body = body.replace(fechaSol,     v_fecha);

        body = body.replace(nombreTit,    tit.nombre);
        body = body.replace(apellido1Tit, tit.apUno);
        body = body.replace(apellido2Tit, tit.apDos);
        body = body.replace(rutTit,       tit.rut);

        body = body.replace(nombreSol,    sol.nombre);
        body = body.replace(apellido1Sol, sol.apUno);
        body = body.replace(apellido2Sol, sol.apDos);
        body = body.replace(rutSol,       sol.rut);

        if (usuario != null){
            body = body.replace(nombre,       usu.nombre);
            body = body.replace(apUno,        usu.apUno);
            body = body.replace(apDos,        usu.apDos);
            body = body.replace(username,     usu.username);
            body = body.replace(idSolicitud,  idSol);
            sol.email=usu.email;    
        }

        let motor = {
            body    : body,
            asunto  : datosMail.info[0],
            noreply : datosMail.info[2]
        }

        let conexion = nodemailer.createTransport({
            host: config.SMTP_HOST,
            port: config.SMTP_PORT,
            tls : { secureProtocol: "TLSv1_method" }
        });

        let femail = {
            from   : motor.noreply,
            to     : sol.email,
            //cc     : tit.email,
            subject: motor.asunto,
            html   : motor.body
        };

        let res = await envio(conexion,femail);

        return res;       
    } catch (err) {
        console.error("Error en helpers/enviarCorreo: " + err);
        return ({status:500,message:"Error en helpers/enviarCorreo: "+err});
    }
};

async function envio(transporter,email){
    return new Promise ((resolve,reject)=>{
        transporter.sendMail(email, function(error, info){
            if (error){
                console.log(error);
                resolve({status:1,message:error});
            } else {
                console.log("Email sent " + info.response);
                resolve({status:0,message:''});
            };
        });
    })         
}

async function enviarCorreo2(datos, idPlantilla) {
    let resul=0;
    let tit;
    let sol;
    let now   = new Date();
//    let day   = now.getDay();
//    let month = now.getMonth();
//    let year  = now.getFullYear();
//    let v_fecha = day+'/'+month+'/'+year;
    let v_fechaHora=((await utilModel.leeFechaHora()).message).split(' ');
    let v_fecha=v_fechaHora[0];

    try {
        var v_idTipoPerTit= parseInt((await utilModel.leeVar("id_tipoper_titular")).message);
        var v_idTipoPerSol= parseInt((await utilModel.leeVar("id_tipoper_solicitante")).message);
        var datosMail     = await utilModel.leeTabPlantilla(idPlantilla);

        for (let per of datos){
            if (per.idTipoPer==v_idTipoPerTit){
                tit={
                    nombre:per.nombre,
                    apUno :per.apUno,
                    apDos :per.apDos,
                    rut   :per.rut+'-'+per.dv,
                    email :per.email
                }
            }else if (per.idTipoPer==v_idTipoPerSol){
                sol={
                    nombre:per.nombre,
                    apUno :per.apUno,
                    apDos :per.apDos,
                    rut   :per.rut+'-'+per.dv,
                    email :per.email
                }
            }
        }

        async.waterfall([

            function renderMail(done){

                var body = datosMail.info[1];  //cuerpo

                const fechaSol     = /@{fechaSol}/gi;

                const nombreTit    = /@{nombreTit}/gi;
                const apellido1Tit = /@{apellido1Tit}/gi;
                const apellido2Tit = /@{apellido2Tit}/gi;
                const rutTit       = /@{rutTit}/gi;

                const nombreSol    = /@{nombreSol}/gi;
                const apellido1Sol = /@{apellido1Sol}/gi;
                const apellido2Sol = /@{apellido2Sol}/gi;
                const rutSol       = /@{rutSol}/gi;

                body = body.replace(fechaSol,     v_fecha);

                body = body.replace(nombreTit,    tit.nombre);
                body = body.replace(apellido1Tit, tit.apUno);
                body = body.replace(apellido2Tit, tit.apDos);
                body = body.replace(rutTit,       tit.rut);

                body = body.replace(nombreSol,    sol.nombre);
                body = body.replace(apellido1Sol, sol.apUno);
                body = body.replace(apellido2Sol, sol.apDos);
                body = body.replace(rutSol,       sol.rut);

                let motor = {
                    body    : body,
                    asunto  : datosMail.info[0],
                    noreply : datosMail.info[2]
                }

                done(null,motor);
            }
        , function sendMail(motor,done){
                
                let conexion = nodemailer.createTransport({
                    host: config.SMTP_HOST,
                    port: config.SMTP_PORT,
                    tls : { secureProtocol: "TLSv1_method" }
                });

                let email = {
                    from   : motor.noreply,
                    to     : sol.email,
                    //cc     : tit.email,
                    subject: motor.asunto,
                    html   : motor.body
                };

                conexion.sendMail(email, (error, info) =>{
                    if (error){
                        console.log(error);
                        resul=1;
                    } else {
                        console.log("Email sent " + info.response);
                        resul=0;
                    }
                });
                done(null);
        }]); 
        return resul;       
    } catch (err) {
        console.error("Error en helpers/enviarCorreo: " + err);
    }
};

module.exports = {
    enviarCorreo
};