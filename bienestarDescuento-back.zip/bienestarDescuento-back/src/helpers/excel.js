const xlsxtojson = require("xlsx-to-json-lc");
const readXlsxFile = require('read-excel-file/node');
const validator = require('jsonschema').Validator;
const fs = require('fs');
const Ajv = require('ajv');
const utilModel = require('../models/util.model');

var ajv = new Ajv(); // options can be passed, e.g. {allErrors: true}

const schema = {
    'NOMBRES': {
        prop: 'nombres',
        type: String,
        parse(value) {
            return value.replace(/[&\/\\+$~%'"*<>°¨´]/g, '')
        },
        required: false
    },
    'APELLIDO_1': {
        prop: 'apellido_1',
        type: String,
        parse(value) {
            return value.replace(/[&\/\\+$~%'"*<>°¨´]/g, '')
        },
        required: false
    },
    'APELLIDO_2': {
        prop: 'apellido_2',
        type: String,
        parse(value) {
            return value.replace(/[&\/\\+$~%'"*<>°¨´]/g, '')
        }

    },
    'DOC IDENTIDAD': {
        prop: 'persona',
        type: {
            'idTipoDoc': {
                prop: 'idTipoDoc',
                type: Number,
                required: false
            },
            'DV': {
                prop: 'dv',
                type: String,
                parse(value) {
                    return utilModel.parseToString(value)
                }
            },
            'NUMERO DOCUMENTO / RUN': {
                prop: 'numDoc',
                type: String,
                parse(value) {
                    return utilModel.parseToString(value)
                },
                required: false
            },
            "idPais": {
                prop: 'idPais',
                type: Number,
                required: false
            },
        }
    },
    'GENERO': {
        prop: 'sexo',
        type: String,
        parse(value) {
            return utilModel.parseToString(value)
        },
        required: false
    },
    'DOMICILIO': {
        prop: 'domicilio',
        type: String,
        parse(value) {
            return value.replace(/[&\/\\+$~%'"*<>°¨´]/g, '')
        },
        required: false
    },
    'idComuna': {
        prop: 'idComuna',
        type: String,
        required: false
    },
    'PATENTE': {
        prop: 'patente',
        type: String
    },
    "FECHA_NACIMIENTO": {
        prop: "fecNac",
        type: String,
        parse(value) {
            return utilModel.parseToDateString(value)
        },
        required: false
    },
    "EMAIL": {
        prop: "email",
        type: String,
        required: false
    },
    "FUNCION_DEL_TRABAJADOR":{
        prop: "funcion",
        type: String,
        parse(value) {
            return value.replace(/[&\/\\+$~%'"*<>°¨´]/g, '')
        },
        required: false
    },
    "FUNCION_ESENCIAL":{
        prop: "esencial",
        type: String,
        parse(value) {
            return utilModel.parseToString(value)
        },
        required: false
    },
    "PERMITE_INTERREGIONALES":{
        prop: "interregional",
        type: String,
        parse(value) {
            return utilModel.parseToString(value)
        },
        required: false
    },
    'idArea': {
        prop: 'idArea',
        type: Number,
        required: false
    },
    'PERSONAS REPETIDAS': {
        prop: 'repetidos',
        type: {
            'idTipoDoc': {
                prop: 'idTipoDoc',
                type: Number,
                required: false
            },
            'NUMERO DOCUMENTO / RUN': {
                prop: 'numDoc',
                type: String,
                parse(value) {
                    return utilModel.parseToString(value)
                },
                required: false
            },
            "idPais": {
                prop: 'idPais',
                type: Number,
                required: false
            }
        }
    }
}

async function excelSchemaParser(filePath) {
    return new Promise((resolve, reject) => {

        var ajv = new Ajv({ allErrors: true, jsonPointers: true });
        require('ajv-errors')(ajv);

        var schemaPersona = JSON.parse(fs.readFileSync(
            __dirname + '/../schemas/salvoconductoEmpresaPersona.schema', 'utf-8'));
        var validate = ajv.compile(schemaPersona);

        readXlsxFile(filePath, { sheet: 'codigos', schema }).then(({ rows, errors }) => {
            let trabajador = [];
            let idPersonas = [];
            let uniqueErrList = [];
            let valid;

            errors.length === 0

            for (var i = 0; i < rows.length && i < 200; i++) {
                if (Object.keys(rows[i]).length >= 8) {

                    idPersonas.push(rows[i].repetidos);
                    delete rows[i].repetidos;
                    trabajador.push(rows[i]);
                    valid = validate(idPersonas);

                    if (!valid) {
                        uniqueErrList.push('Fila ' + (i + 2) + ', Num. Doc ' + rows[i].persona.numDoc);
                        idPersonas.pop();
                    }
                }
            }

            // test if any parse error
            var resultTrabajador = schemaParser(trabajador);
            if (resultTrabajador.length > 0 || uniqueErrList.length > 0) {
                let errResult = {
                    registros: resultTrabajador,
                    repetidos: uniqueErrList
                }
                reject(errResult);
            }

            if (trabajador.length > 0 && trabajador[0].persona.numDoc != '1234567')
                resolve(trabajador);
            else {
                let errResult = {
                    general: 'No se encontraron registros válidos en el excel.'
                }

                if (trabajador.length > 0 && trabajador[0].persona.numDoc == '1234567') {
                    errResult.general = 'Debe modificar la fila 2 (se incluye solo como ejemplo en la planilla).'
                }

                reject(errResult);
            }
        }).catch((errors) => {
            //console.log(errors);

            let errResult = {
                general: 'Excel con errores de formato, use la plantilla actualizada disponible en la página.'
            }

            reject(errResult);
        });
    })
}

function schemaParser(workers) {
    var ajv = new Ajv({ allErrors: true, jsonPointers: true });
    require('ajv-errors')(ajv);

    var schemaOverall = JSON.parse(fs.readFileSync(
        __dirname + '/../schemas/salvoconductoEmpresaOverall.schema', 'utf-8'));

    var validate = ajv.compile(schemaOverall);

    var errList = [];
    for (i = 0; i < workers.length; i++) {
        var row = {
            fila: i + 2,
            errores: []
        };

        var valid = validate(workers[i]);

        if (!valid) {
            const iterator = validate.errors;

            for (const value of iterator) {
                var patternValue = {};
                var fecError = {};

                if (value.keyword == "errorMessage" && value.message.length > 0) {
                    row.errores.push(value.message);
                }

                // uncomment next line for debugging ...
                //console.log("Row: " + i + " - " + JSON.stringify(value, null, 2));
            }

        }

        if (utilModel.parseDate(workers[i].fecNac) == null) {
            row.errores.push("formato fecha debe ser dd/mm/aaaa");
        }

        if (row.errores.length > 0)
            errList.push(row);
    }

    return errList;
}

async function excelParser(filePath) {
    return new Promise((resolve, reject) => {

        //console.log("filePath: " + filePath);

        xlsxtojson({
            input: filePath,
            output: null,
            lowerCaseHeaders: true
        }, function (err, result) {
            if (err) {
                reject(err);
            }

            resolve(result);
        });
    })
}

module.exports = {
    excelParser,
    excelSchemaParser
}