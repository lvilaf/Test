const soapRequest = require('easy-soap-request');
const utilModel = require('../models/util.model');
 
async function datosRegCivil(rut, dv) {
  let v_status;
  let v_message;
  const rutOut = /rutIn/gi;
  const dvOut  = /dvIn/gi;
  const ambOut = /ambIn/gi;

  const url = process.env.ESBPERSONALWS;
  const sampleHeaders = {
          'user-agent': 'sampleTest',
          'Content-Type': 'text/xml;charset=UTF-8'
  };
  var XMLEnv = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:per="http://personal.srcei.interior.cl/">
                  <soapenv:Header/>
                    <soapenv:Body>
                      <per:personal>
                        <rut>rutIn</rut>
                        <dv>dvIn</dv>
                        <ambiente>ambIn</ambiente>
                      </per:personal>
                    </soapenv:Body>
                </soapenv:Envelope>`;                  

  XMLEnv = XMLEnv.replace(rutOut, rut);
  XMLEnv = XMLEnv.replace(dvOut , dv);
  XMLEnv = XMLEnv.replace(ambOut , 1);
  let datosPersonales;
  try {
    const { response } = await soapRequest({url: url, headers: sampleHeaders, xml: XMLEnv});
    const { headers, body, statusCode} = response;
  
    const menOut = /&lt;/gi;
    const mayOut = /&gt;/gi;
    var bodyRes = body;
    bodyRes = bodyRes.replace(menOut,'<');
    bodyRes = bodyRes.replace(mayOut,'>');
    var arrayDeCadenas = bodyRes.split('<return>');
    var respuestaXml = arrayDeCadenas[1].split('</return>');
    var desglose0 = respuestaXml[0].split('<documento xmlns=');
    var desglose1 = respuestaXml[0].split('XMLSchema-instance">');
    const paiOut = /<paisOrigen\/>/gi;
    var desglose2 = desglose1[1].replace(paiOut,'<paisOrigen></paisOrigen>');
    desglose2 = desglose0[0]+'<documento>'+desglose2;
    // console.log("getXML---> " + desglose2); 
    const myJson = utilModel.toJson(desglose2);
    let fechaNacimiento = myJson.documento.datosPersonal.fechaNacimiento.fechaValida;
    if (myJson.documento.datosPersonal.fechaNacimiento.fechaValida==undefined || myJson.documento.datosPersonal.fechaNacimiento.fechaValida==null){
      fechaNacimiento=myJson.documento.datosPersonal.fechaNacimiento.fechaTruncada;
    }
    let fechaDefuncion = myJson.documento.datosPersonal.fechaDefuncion.fechaValida;
    if (myJson.documento.datosPersonal.fechaDefuncion.fechaValida==undefined || myJson.documento.datosPersonal.fechaDefuncion.fechaValida==null){
      fechaDefuncion=myJson.documento.datosPersonal.fechaDefuncion.fechaTruncada;
    }
    fechaNacimiento=fechaNacimiento.substring(8,10)+'/'+fechaNacimiento.substring(5,7)+'/'+fechaNacimiento.substring(0,4);
    fechaDefuncion =fechaDefuncion.substring(8,10)+'/'+fechaDefuncion.substring(5,7)+'/'+fechaDefuncion.substring(0,4);
    datosPersonales = {
      rut                    : myJson.documento.datosPersonal.run.numero,
      dv                     : myJson.documento.datosPersonal.run.dv,
      apPaterno              : myJson.documento.datosPersonal.nombre.apellidoPaterno,
      apMaterno              : myJson.documento.datosPersonal.nombre.apellidoMaterno,
      nombre                 : myJson.documento.datosPersonal.nombre.nombres,
      genero                 : myJson.documento.datosPersonal.sexo,
      estadoCivil            : myJson.documento.datosPersonal.estadoCivil,
      fechaNacimiento        : fechaNacimiento,
      fechaDefuncion         : fechaDefuncion,
      // fechaNacimientoValida  : myJson.documento.datosPersonal.fechaNacimiento.fechaValida,
      // fechaNacimientoTruncada: myJson.documento.datosPersonal.fechaNacimiento.fechaTruncada,
      // fechaDefuncionValida   : myJson.documento.datosPersonal.fechaDefuncion.fechaValida,
      // fechaDefuncionTruncada : myJson.documento.datosPersonal.fechaDefuncion.fechaTruncada,
      nacionalidad           : myJson.documento.datosPersonal.nacionalidad
    }    
    // let fechaNacimiento = myJson.documento.datosPersonal.fechaNacimiento.fechaValida;
    // if (myJson.documento.datosPersonal.fechaNacimiento.fechaValida==undefined || myJson.documento.datosPersonal.fechaNacimiento.fechaValida==null){
    //   fechaNacimiento=myJson.documento.datosPersonal.fechaNacimiento.fechaTruncada;
    // }
    // let fechaDefuncion = myJson.documento.datosPersonal.fechaDefuncion.fechaValida;
    // if (myJson.documento.datosPersonal.fechaDefuncion.fechaValida==undefined || myJson.documento.datosPersonal.fechaDefuncion.fechaValida==null){
    //   fechaDefuncion=myJson.documento.datosPersonal.fechaDefuncion.fechaTruncada;
    // }
    // datosPersonales = {
    //   run             : myJson.documento.datosPersonal.run.numero,
    //   dv              : myJson.documento.datosPersonal.run.dv,
    //   apPat           : myJson.documento.datosPersonal.nombre.apellidoPaterno,
    //   apMat           : myJson.documento.datosPersonal.nombre.apellidoMaterno,
    //   nombre          : myJson.documento.datosPersonal.nombre.nombres,
    //   sexo            : myJson.documento.datosPersonal.sexo,
    //   estadoCivil     : myJson.documento.datosPersonal.estadoCivil,
    //   fechaNacimiento : fechaNacimiento,
    //   fechaDefuncion  : fechaDefuncion,
    //   nacionalidad    : myJson.documento.datosPersonal.nacionalidad
    // }
    v_status=200;
    v_message='';
  } catch (error) {
    v_status=300;
    v_message="no existe "+rut;
    console.log ("no existe "+rut);
  }
  return ({status:v_status,message:v_message,datosPersona:datosPersonales});
}

module.exports = {
    datosRegCivil
};


