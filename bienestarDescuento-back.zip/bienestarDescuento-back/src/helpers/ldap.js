const config = require('../../config/config');
const fetch = require("node-fetch");

async function loginLdap(req){
    var urlApiLdap = '';

    if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
        urlApiLdap   = config.URL_APILDAP_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        urlApiLdap    = config.URL_APILDAP_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        urlApiLdap    = config.URL_APILDAP_PROD;
    }else{
        res.status(400).send({status:400,message:'Origin NO Autorizado '+req.get('origin')});
    }

    try {
        const baseUrl = `${urlApiLdap}/api/login_ldap` // url api login_ldap
        
        const options = {
            method: 'POST',
            headers:{
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(req.body)
        }

        const resp = await fetch(baseUrl, options)
        const data = await resp.json()

        return data
    } catch (err) {
        console.log(err);
    }
}

async function leeLdap(req){
    var urlApiLdap = '';

    if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
        urlApiLdap   = config.URL_APILDAP_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        urlApiLdap    = config.URL_APILDAP_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        urlApiLdap    = config.URL_APILDAP_PROD;
    }else{
        res.status(400).send({status:400,message:'Origin NO Autorizado '+req.get('origin')});
    }
    
    try {
        const baseUrl = `${urlApiLdap}/api/lee_ldap` // url api lee_ldap
        
        const options = {
            method: 'POST',
            headers:{
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(req.body)
        }

        const resp = await fetch(baseUrl, options)
        const data = await resp.json()

        return data
    } catch (err) {
        console.log(err);
    }
}

module.exports = {
    loginLdap,
    leeLdap
};