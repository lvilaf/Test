const fetch = require("node-fetch");
const HttpProxyAgent = require('https-proxy-agent');
const config = require('../../config/config');
const proxy = config.PROXY;

async function loginOneReg(req,datos) {
  var api_oneReg = '';
  var appkey     = '';

  if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
      api_oneReg = config.API_ONEREG_DESA;
      appkey     = config.APPKEY_DESA;
  }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
      api_oneReg = config.API_ONEREG_TEST;
      appkey     = config.APPKEY_TEST;
  }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
      api_oneReg = config.API_ONEREG_PROD;
      appkey     = config.APPKEY_PROD;
  }

  const response = await fetch(api_oneReg + '/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'appkey': appkey },
      body: JSON.stringify(datos) ,
      agent: new HttpProxyAgent(proxy) 
  });  
  const resp = await response.text();
  var a  = JSON.parse(resp);
  return a;
}

async function infoPersona(req,datos) {
  var api_oneReg = '';
  var appkey     = '';

  if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
      api_oneReg = config.API_ONEREG_DESA;
      appkey     = config.APPKEY_DESA;
  }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
      api_oneReg = config.API_ONEREG_TEST;
      appkey     = config.APPKEY_TEST;
  }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
      api_oneReg = config.API_ONEREG_PROD;
      appkey     = config.APPKEY_PROD;
  }

  try{
      const response = await fetch(api_oneReg + '/user/info', {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json', 'appkey': appkey},
                                  body: JSON.stringify(datos),
                                  agent: new HttpProxyAgent(proxy) 
      });
                                
      if(await response.status === 200) {
          const resp = await response.text();
          let out  = JSON.parse(resp);
          return out;
      }
      if(await response.status === 400) {
          const resp = await response.text();
          let out  = JSON.parse(resp);
          return out;
      } else {
          throw new Error("infoPersona OneReg responde diferente de 200 y 400, responde: " + response.status);
      }
  } catch(error) {
    console.error("infoPersona: errores en infoPersona: " + error);
    return {"status": "0"};
  }
}

async function createOneReg(req,datos) {
    var api_oneReg = '';
    var appkey     = '';
  
    if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
        api_oneReg = config.API_ONEREG_DESA;
        appkey     = config.APPKEY_DESA;
    }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
        api_oneReg = config.API_ONEREG_TEST;
        appkey     = config.APPKEY_TEST;
    }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
        api_oneReg = config.API_ONEREG_PROD;
        appkey     = config.APPKEY_PROD;
    }
  
    const response = await fetch(api_oneReg + '/user/create', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json', 'appkey': appkey },
                              body: JSON.stringify(datos) ,
                              agent: new HttpProxyAgent(proxy) 
    });  
    const resp = await response.text();
    var a  = JSON.parse(resp);
    return a;
  }
  
  async function restoreOneReg(req,datos) {
  var api_oneReg = '';
  var appkey     = '';

  if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
      api_oneReg = config.API_ONEREG_DESA;
      appkey     = config.APPKEY_DESA;
  }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
      api_oneReg = config.API_ONEREG_TEST;
      appkey     = config.APPKEY_TEST;
  }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
      api_oneReg = config.API_ONEREG_PROD;
      appkey     = config.APPKEY_PROD;
  }

  const response = await fetch(api_oneReg + '/login/restore', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'appkey': appkey},
    body: JSON.stringify(datos) ,
    agent: new HttpProxyAgent(proxy) 
    });  
    const resp = await response.text();
    var a  = JSON.parse(resp);
    return a;
}

async function updateOneReg(req, datos) {
  var api_oneReg = '';
  var appkey     = '';

  if (req.get('origin')       == config.ORIGIN_AUTH_DESA){
      api_oneReg = config.API_ONEREG_DESA;
      appkey     = config.APPKEY_DESA;
  }else if (req.get('origin') == config.ORIGIN_AUTH_TEST){
      api_oneReg = config.API_ONEREG_TEST;
      appkey     = config.APPKEY_TEST;
  }else if (req.get('origin') == config.ORIGIN_AUTH_PROD){
      api_oneReg = config.API_ONEREG_PROD;
      appkey     = config.APPKEY_PROD;
  }
  
  const response = await fetch(api_oneReg + '/login/update', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'appkey': appkey},
    body: JSON.stringify(datos),
    agent: new HttpProxyAgent(proxy) 
    });  
    const resp = await response.text();
    var a  = JSON.parse(resp);
    return a;;
}

module.exports = {
    loginOneReg,
    infoPersona,
    createOneReg,
    restoreOneReg,
    updateOneReg
};