var jwt = require('jsonwebtoken');
const crypto = require('crypto');
const config = require('../../config/config');
/*
async function generateOK(payl) {
    var u = {
        username: payl.numDoc
    };
    return token = jwt.sign(u, config.PRIVATE_KEY, {
        expiresIn:"20m" // expires in 3 minutos
    })
};
*/
async function generateTokenCU() {

    //Creacion al azar del codigo numerico de 8 digitos para hashear
    var rndCode = generateOTP();  
    //Creacion del hash del codigo para envio por correo
    var tokencu = await crypto.createHash('sha256').update(rndCode).digest('hex'); 
    return tokencu;
};

function generateOTP() { 
    var digits = '0123456789abcdefghijkABCDEFGHIJK'; 
    let OTP = ''; 
    for (let i = 0; i < 8; i++ ) { 
        OTP += digits[Math.floor(Math.random() * digits.length)]; 
    } 
    return OTP; 
} 

module.exports = {
//    generateOK,
    generateTokenCU
};