'use strict';

const oracledba = require('oracledb');
const app = require('./app');
const config = require('../config/config');

//Variable global
global.dbOraclePoolGlb   = undefined;
/* 
Metodo anonimo async/await 
*/
(async function() {

    try {
        console.log("Inicializando pool Oracle...");

        const dbOraclePool = await oracledba.createPool({

            user            : config.DB_USER,
            password        : config.DB_PASS,
            connectString   : config.ORACLEDB,
            homogeneous     : true,        // all connections in the pool have the same credentials
            poolAlias       : 'BienestarDescuentoPool', // set an alias to allow access to the pool via a name.
            poolIncrement   : 1,           // only grow the pool by one connection at a time
            poolMax         : 10,          // maximum size of the pool. Increase UV_THREADPOOL_SIZE if you increase poolMax (default 4)
            poolMin         : 0,           // start with no connections; let the pool shrink completely
            poolPingInterval: 60,          // check aliveness of connection if idle in the pool for 60 seconds
            poolTimeout     : 60,          // terminate connections that are idle in the pool for 60 seconds
            queueMax        : 500,         // don't allow more than 500 unsatisfied getConnection() calls in the pool queue
            queueTimeout    : 60000        // terminate getConnection() calls queued for longer than 60000 milliseconds
            //stmtCacheSize   : 30,          // number of statements that are cached in the statement cache of each connection
            //_enableStats    : false        // record pool usage statistics that can be output with pool._logStats()
        });
        console.log('dbOraclePool en funcion');
        dbOraclePoolGlb = dbOraclePool;

        app.listen(config.port, () => {
            console.log(`API REST Corriendo en  http:localhost:${config.port}!`);
        });

        return { dbOraclePool };
    } catch (err) {
        console.error("init() error: " + err.message);
    }

})();