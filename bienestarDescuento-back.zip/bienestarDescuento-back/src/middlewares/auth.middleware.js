'use strict'

const services = require('../services/services');
const utilModel  = require('../models/util.model');
var captcha = require('../helpers/captcha');

async function valida(origin){
    let habilitado = ['http://bienestardescuentos.desarrollo.intranet.gov.cl', 'http://bienestardescuentos.testing.intranet.gov.cl', 'https://bienestardescuentos.interior.gob.cl','http://localhost:4200'];
    let existe = 0;
    if (origin && origin.length > 6) {
        for (var x = 0; x < habilitado.length; x++) {
            if (habilitado[x]==origin) {
                existe = 1;
                break;
            }
        }
    }else{
        existe = 2;
    }
    return existe;
}

async function isAuth(req, res, next) {
    let val = await valida(req.headers.origin);
    if (val==2){
        return res.status(403).send({status: 300, message: 'acceso invalido2' });
    } else if (val==0){
        return res.status(403).send({status: 300, message: 'acceso invalido1' });
    } 

    if (!req.headers.authorization) {
        return res.status(403).send({status: 300, message: 'No tiene autorizacion' });
    }
    if (req.headers.authorization.split(" ").length > 1) {
        const token = req.headers.authorization.split(" ")[1];
        services.decodeToken(token)
            .then(response => {
                    req.user = response;
                    next();
                },
                response => {
                    res.status(response.status).send({ message: response.message });
                }
            ).catch(response => {
                res.status(response.status);
            });
    } else {
        return res.status(400).send({status: 300, message: 'Petición erronea' });
    }
}

async function isOrigin(req, res, next) {
    let val = await valida(req.headers.origin);
    if (val==2){
        return res.status(403).send({status: 300, message: 'acceso invalido2' });
    } else if (val==0){
        return res.status(403).send({status: 300, message: 'acceso invalido1' });
    };
    next(); 
}

async function validaCaptcha(req, res, next){
    let val = await valida(req.headers.origin);
    if (val==2){
        return res.status(403).send({status: 300, message: 'acceso invalido2' });
    } else if (val==0){
        return res.status(403).send({status: 300, message: 'acceso invalido1' });
    }
    try {
        if ((await utilModel.leeVar('validaCaptcha')).message=='S'){                
            captcha.validarCaptcha(req, res, next);
        }else{
            next();
        }                
    } catch (error) {
        res.status(200).json({
            status: 402,
            success: false,
            message: "error captcha"
        });            
    }    
}

module.exports = {
    isAuth,
    isOrigin,
    validaCaptcha
}