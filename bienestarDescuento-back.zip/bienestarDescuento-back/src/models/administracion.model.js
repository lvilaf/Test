'use restrict'

const { autoCommit } = require('oracledb');
const oracledb = require('oracledb');
const externalDeps = require('../helpers/externaldeps');

async function mantencionUsuario(parametro) {
    let connection;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN PKG_ADMINISTRACION.PR_MANTENCION_USUARIO(:v_tipo,:v_idUsuario,:v_idAutoridad,:v_rut,:v_dv,:v_apUno,:v_apDos,:v_nombre,'+
                                                                   ':v_email,:v_username,:v_obs,:v_vigente,:v_listaPef,'+
                                                                   ':v_fecTran,:v_ipTran,:v_idUsuarioP,:v_cod_error,:v_msj_error); END;';      
        let result = await connection.execute(sql, {
            v_tipo       : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.tipo},
            v_idUsuario  : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: parametro.idUsuario},
            v_idAutoridad: { type: oracledb.NUMBER, dir: oracledb.BIND_IN   ,val: parametro.idAutoridad},
            v_rut        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.rut},
            v_dv         : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.dv},
            v_apUno      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.apUno},
            v_apDos      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.apDos},
            v_nombre     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.nombre},
            v_email      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.email},
            v_username   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.username},
            v_obs        : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.obs},
            v_vigente    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
            v_listaPef   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.listaPef},
            v_fecTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
            v_ipTran     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
            v_idUsuarioP : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuarioP},
            v_cod_error  : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
            v_msj_error  : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
        }, { autoCommit: true });

        v_status     =result.outBinds.v_cod_error;
        v_message    =result.outBinds.v_msj_error;

        if (v_status==0){
            v_status=200;
        }
        let estado = {
            status     : v_status,
            message    : v_message,
            obj        : {idUsuario:result.outBinds.v_idUsuario}
        }
        return estado;
    } catch (err) {
        console.error("Error en model/mantencionUsuario " + err);
        return ({status:500,message:"Error en model/mantencionUsuario: " + err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/mantencionUsuario " + err);
                return ({status:501,message:"Error en model/mantencionUsuario: " + err})
            }
        }
    }
}

async function listaRut() {
    let connection;
    let v_cont=0;
    let resultado;
    let v_estado;

    let v_fechaNacimientoValida;
    let v_fechaNacimientoTruncada;
    let v_fechaDefuncionValida;
    let v_fechaDefuncionTruncada;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_AAACRUCE; END;';
        resultado = await connection.execute(sql, {
            v_cursor : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
        });  

        const v_cursor2 = resultado.outBinds.v_cursor;
        let row; //Traer de a una fila

        while ((row = await v_cursor2.getRow())) {
            v_cont++;
            console.log(v_cont+' '+row[0]);
            let respuesta = await externalDeps.datosRegCivil(row[0], row[1]);

            if (respuesta.status==200){
                v_fechaNacimientoValida  =respuesta.obj.fechaNacimientoValida;
                v_fechaNacimientoTruncada=respuesta.obj.fechaNacimientoTruncada;
                v_fechaDefuncionValida   =respuesta.obj.fechaDefuncionValida;
                v_fechaDefuncionTruncada =respuesta.obj.fechaDefuncionTruncada;
            }
        
            let v_fecha   = null;
            if (respuesta.status==200){
                v_estado='';
                if (respuesta.obj.fechaDefuncion=='0000-00-00'){
                    v_estado='V';
                }else{
                    v_estado='F';
                    v_fecha =respuesta.obj.fechaDefuncion;
                }
    
                v_sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_AAACRUCE(:v_rut,:v_estado,'+
                                                                  ':v_fechaNacimientoValida,:v_fechaNacimientoTruncada,:v_fechaDefuncionValida,:v_fechaDefuncionTruncada,'+
                                                                  ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
                let result = await connection.execute(v_sql, {
                    v_rut            : { type: oracledb.NUMBER,  dir: oracledb.BIND_IN,    val: row[0]},
                    v_estado         : { type: oracledb.VARCHAR, dir: oracledb.BIND_IN,    val: v_estado},
                    v_fechaNacimientoValida  : { type: oracledb.VARCHAR, dir: oracledb.BIND_IN,    val: v_fechaNacimientoValida},
                    v_fechaNacimientoTruncada: { type: oracledb.VARCHAR, dir: oracledb.BIND_IN,    val: v_fechaNacimientoTruncada},
                    v_fechaDefuncionValida   : { type: oracledb.VARCHAR, dir: oracledb.BIND_IN,    val: v_fechaDefuncionValida},
                    v_fechaDefuncionTruncada : { type: oracledb.VARCHAR, dir: oracledb.BIND_IN,    val: v_fechaDefuncionTruncada},
                    v_fecTran        : { type: oracledb.STRING,  dir: oracledb.BIND_IN,    val: null},
                    v_ipTran         : { type: oracledb.STRING,  dir: oracledb.BIND_IN,    val: null},
                    v_idUsuario      : { type: oracledb.NUMBER,  dir: oracledb.BIND_IN,    val: null},
                    v_cod_error      : { type: oracledb.NUMBER,  dir: oracledb.BIND_INOUT, val: null},
                    v_msj_error      : { type: oracledb.STRING,  dir: oracledb.BIND_INOUT, val: null}
                }, { autoCommit: true } );
    
                v_status     =result.outBinds.v_cod_error;
                v_message    =result.outBinds.v_msj_error;
                if (result.outBinds.v_cod_error!=0){
                    console.log('error -->'+row[0]);
                }    
            }
        }
        await v_cursor2.close();
        return null;
    } catch (err) {
        console.error("Error en model/listaRut: " + err);
        return ({status:500,message:"Error en model/listaRut: " + err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/listaRut: " + err);
                return ({status:501,message:"Error en model/listaRut: " + err})
            }
        }
    }
}


module.exports = {
    mantencionUsuario,
    listaRut
};