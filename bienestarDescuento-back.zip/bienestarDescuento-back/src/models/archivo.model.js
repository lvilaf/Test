'use restrict'

const { autoCommit, DB_TYPE_BINARY_DOUBLE } = require('oracledb');
const oracledb = require('oracledb');
const helpersAlfresco = require('../helpers/alfresco');
const utilModel = require('./util.model');

async function leeArchivo(parametro) {
    let connection;
    let v_fila;
    let resultado;
    let v_archivo=[];

    try {
        connection = await dbOraclePoolGlb.getConnection();
            const sql = 'BEGIN :v_cursor := PKG_GRABACION.FN_LEE_ARCHIVO(:v_idAutoridad,:v_ano,:v_mes,:v_idUsuario,'+
                                                                        ':v_fecArchivo,:v_fileName,:v_extension); END;';
            resultado = await connection.execute(sql, {
                v_idAutoridad       : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.idAutoridad},
                v_ano               : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.ano},
                v_mes               : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.mes},
                v_idUsuario         : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.idUsuario},
                v_fecArchivo        : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.fecArchivo},
                v_fileName          : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.fileName},
                v_extension         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.extension},
                v_cursor            : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });   
        const v_cursor2 = resultado.outBinds.v_cursor;
        let row; //Traer de a una fila
        while ((row = await v_cursor2.getRow())) {
            let v_obj = {
                idAutoridad      : row[0],
                glosaAutoridad   : row[1],
                ano              : row[2],
                mes              : row[3],
                idUsuario        : row[4],
                userName         : row[5],
                fecArchivo       : row[6],
                fileName         : row[7],
                extension        : row[8]
            }
            v_archivo.push(v_obj);
        }
        await v_cursor2.close();

        if (v_archivo.length==0){
            v_fila = {
                status : 400,
                message: 'No Existe Archivo'
            };
        }else{
            v_fila = {
                status   : 200,
                message  : '',
                obj      : v_archivo
            }    
        }
        return v_fila;
    } catch (err) {
        console.error("Error en model/leeArchivo " + err);
        return ({status:500,message:"Error en model/leeArchivo " + err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/leeArchivo " + err);
                return ({status:501,message:"Error en model/leeArchivo " + err})
            }
        }
    }
}

async function grabaArchivo(req,parametro) {
    let connection;
    let v_status=0;
    let v_message='';
    let v_listaArchivo='';
    let v_sql;

    try {
        let respuesta = await helpersAlfresco.renombrarAlfresco(req, parametro);
        
        if (respuesta.status == 200) {
            v_listaArchivo   =respuesta.lista;
        }else{
            v_status =respuesta.status;
            v_message=respuesta.message;
        }    
  
        if (v_listaArchivo!=''){
            connection = await dbOraclePoolGlb.getConnection();
            v_sql = 'BEGIN PKG_NEGOCIO.PR_GRABA_ARCHIVO(:v_idAutoridad,:v_ano,:v_mes,:v_listaArchivo,:v_idUsuario,:v_fecArchivo,:v_obs,'+
                                                       ':v_fecTran,:v_ipTran,:v_idUsuarioP,:v_cod_error,:v_msj_error); END;';
            let result = await connection.execute(v_sql, {
                v_idAutoridad       : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.idAutoridad},
                v_ano               : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.ano},
                v_mes               : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.mes},
                v_listaArchivo      : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: v_listaArchivo},
                v_idUsuario         : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.idUsuario},
                v_fecArchivo        : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: parametro.fecArchivo},
                v_obs               : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: parametro.obs},
                v_fecTran           : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: null},
                v_ipTran            : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: parametro.ipTran},
                v_idUsuarioP        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.idUsuario},
                v_cod_error         : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT, val: null},
                v_msj_error         : { type: oracledb.STRING, dir: oracledb.BIND_INOUT, val: null}
            }, { autoCommit: true } );
    
            v_status     =result.outBinds.v_cod_error;
            v_message    =result.outBinds.v_msj_error;
            if (result.outBinds.v_cod_error==0){
                v_status     =200;
            }    
        }

        let estado = {
            status          : v_status,
            message         : v_message
        }
        return estado;
    } catch (err) {
        console.error("Error en model/grabaArchivo " + err);
        return ({status:500,message:"Error en model/grabaArchivo " + err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/grabaArchivo " + err);
                return ({status:501,message:"Error en model/grabaArchivo " + err})
            }
        }
    }
}

async function actualizaArchivo(req,parametro) {
    let connection;
    let v_status=0;
    let v_message='';
    let v_listaArchivo='';    
    let v_sql;
    
    try {
        let respuesta = await helpersAlfresco.renombrarAlfresco(req, parametro);
    
        if (respuesta.status == 200) {
            v_listaArchivo   =respuesta.lista;
        }else{
            v_status =respuesta.status;
            v_message=respuesta.message;
        }   

        if (v_listaArchivo!=''){
            connection = await dbOraclePoolGlb.getConnection();
            v_sql = 'BEGIN PKG_GRABACION.PR_ACTUALIZA_ARCHIVO(:v_idAutoridad,:v_ano,:v_mes,:v_listaArchivo,:v_idUsuario,:v_fecArchivo,:v_obs,'+
                                                             ':v_fecTran,:v_ipTran,:v_idUsuarioP,:v_cod_error,:v_msj_error); END;';
            let result = await connection.execute(v_sql, {
                v_idAutoridad       : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.idAutoridad},
                v_ano               : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.ano},
                v_mes               : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.mes},
                v_listaArchivo      : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: v_listaArchivo},
                v_idUsuario         : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.idUsuario},
                v_fecArchivo        : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: parametro.fecArchivo},
                v_obs               : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: parametro.obs},
                v_fecTran           : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: null},
                v_ipTran            : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: parametro.ipTran},
                v_idUsuarioP        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.idUsuario},
                v_cod_error         : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT, val: null},
                v_msj_error         : { type: oracledb.STRING, dir: oracledb.BIND_INOUT, val: null}
            }, { autoCommit: true } );
    
            v_status     =result.outBinds.v_cod_error;
            v_message    =result.outBinds.v_msj_error;
            if (result.outBinds.v_cod_error==0){
                v_status     =200;
            }    
        }

        let estado = {
            status     : v_status,
            message    : v_message
        }
        return estado;
    } catch (err) {
        console.error("Error en model/actualizaArchivo " + err);
        return ({status:500,message:"Error en model/actualizaArchivo " + err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/actualizaArchivo " + err);
                return ({status:501,message:"Error en model/actualizaArchivo " + err})
            }
        }
    }
}

async function borraArchivo(req,parametro) {
    let connection;
    let v_status=0;
    let v_message='';
    let v_sql;

    try {
        let salida = await helpersAlfresco.borrarAlfresco(req, parametro); 

        if (salida.status==200){
            let v_extension=parametro.fileName.substr(parametro.fileName.lastIndexOf("."),parametro.fileName.length);

            connection = await dbOraclePoolGlb.getConnection();
            v_sql = 'BEGIN PKG_GRABACION.PR_BORRA_ARCHIVO(:v_idAutoridad,:v_ano,:v_mes,:v_extension,'+
                                                         ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            let result = await connection.execute(v_sql, {
                v_idAutoridad : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.idAutoridad},
                v_ano         : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.ano},
                v_mes         : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.mes},
                v_extension   : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: v_extension},
                v_fecTran     : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: null},
                v_ipTran      : { type: oracledb.STRING, dir: oracledb.BIND_IN,    val: parametro.ipTran},
                v_idUsuario   : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,    val: parametro.idUsuario},
                v_cod_error   : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT, val: null},
                v_msj_error   : { type: oracledb.STRING, dir: oracledb.BIND_INOUT, val: null}
            }, { autoCommit: true } );
    
            v_status     =result.outBinds.v_cod_error;
            v_message    =result.outBinds.v_msj_error;
    
            if (result.outBinds.v_cod_error==0){
                v_status     =200;
            }    
        }

        let estado = {
            status     : v_status,
            message    : v_message
        }
        return estado;
    } catch (err) {
        console.error("Error en model/borraArchivo " + err);
        return ({status:500,message:"Error en model/borraArchivo " + err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/borraArchivo " + err);
                return ({status:501,message:"Error en model/borraArchivo " + err})
            }
        }
    }
}

module.exports = {
    leeArchivo,
    grabaArchivo,
    actualizaArchivo,
    borraArchivo
};