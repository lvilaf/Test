'use restrict'

const { autoCommit } = require('oracledb');
const oracledb = require('oracledb');

async function leeTablaBase(parametro) {
    let connection;
    let fila;
    let estructura;
    let vector = [];
    let entro;
    let resultado;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        if (parametro.tipo=='leeTabAntecedente'){
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABANTECEDENTE(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });   
        }else if (parametro.tipo=='leeTabArticulo'){ 
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABARTICULO(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabAutoridad'){ 
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABAUTORIDAD(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabCalidad'){ 
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABCALIDAD(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });

        }else if (parametro.tipo=='leeTabCargo'){ 
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABCARGO(:v_id,:v_glosa,:v_tipo,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_tipo          : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.tipoP},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });    
        }else if (parametro.tipo=='leeTabEspecial'){ 
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABESPECIAL(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabMateria'){ 
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABMATERIA(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabMotivo'){ 
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABMOTIVO(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabPerfil'){
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABPERFIL(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabPlantilla'){
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABPLANTILLA(:v_id,:v_nombre,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_nombre        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.nombre},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });   
        // }else if (parametro.tipo=='leeTabProcedencia'){ 
        //     const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABPROCEDENCIA(:v_id,:v_glosa,:v_vigente); END;';
        //     resultado = await connection.execute(sql, {
        //         v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
        //         v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
        //         v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
        //         v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
        //     });
        }else if (parametro.tipo=='leeTabRegProvCom'){ 
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABREGPROVCOM(:v_idRegProvCom,:v_idRegProvComPadre,:v_idTipo,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_idRegProvCom      : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.id},
                v_idRegProvComPadre : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.idPadre},
                v_idTipo            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.idTipo},
                v_glosa             : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa}, 
                v_vigente           : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor            : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabTipo'){
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABTIPO(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabTipoAgr'){
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABTIPOAGR(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabTipoDir'){
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABTIPODIR(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabTipoDoc'){ 
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABTIPODOC(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabTipoSol'){        
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABTIPOSOL(:v_id,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabTipoTra'){
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABTIPOTRA(:v_id,:v_glosa,:v_cierre,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_cierre        : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.cierre},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });
        }else if (parametro.tipo=='leeTabTramite'){
            const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_TABTRAMITE(:v_id,:v_idTipo,:v_glosa,:v_vigente); END;';
            resultado = await connection.execute(sql, {
                v_id            : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.id},
                v_idTipo        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.idTipo},
                v_glosa         : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.glosa},
                v_vigente       : { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.vigente},
                v_cursor        : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            });                
        }

        const v_cursor2 = resultado.outBinds.v_cursor;
        let row; //Traer de a una fila
        fila = {
            status : 400,
            message: 'No Existen en TablaBase '+parametro.tipo,
            obj    : {}
        };
        entro=0;
        while ((row = await v_cursor2.getRow())) {
            entro=1;
            if (parametro.tipo=='leeTabCargo'){ 
                estructura= {
                    id        : row[0],
                    glosa     : row[1],
                    tipo      : row[2],
                    vigente   : row[3]
                }
            }else if (parametro.tipo=='leeTabPlantilla'){  
                estructura= {
                    idPlantilla: row[0],
                    nombre     : row[1],
                    asunto     : row[2],
                    cuerpo     : row[3],
                    remitente  : row[4],
                    obs        : row[5],
                    vigente    : row[6]
                }
            }else if (parametro.tipo=='leeTabRegProvCom'){  
                estructura= {
                    idCom     : row[0],
                    glosaCom  : row[1],
                    vigenteCom: row[2],
                    idPro     : row[3],
                    glosaPro  : row[4],
                    vigentePro: row[5],
                    idReg     : row[6],
                    glosaReg  : row[7],
                    vigenteReg: row[8]
                }
            }else if (parametro.tipo=='leeTabTipoTra'){
                estructura= {
                    id      : row[0],
                    glosa   : row[1],
                    cierre  : row[2],
                    vigente : row[3]
                }
            }else if (parametro.tipo=='leeTabTramite'){
                estructura= {
                    id        : row[0],
                    glosa     : row[1],
                    idTipo    : row[2],
                    glosaTipo : row[3],
                    IMM       : row[4],
                    vigente   : row[5]
                }
    
            }else{                  
                estructura= {
                    id      : row[0],
                    glosa   : row[1],
                    vigente : row[2]
                }
            }
            vector.push(estructura);
        }

        await v_cursor2.close();
        if (entro==1){
            fila = {
                status : 200,
                message: '',
                obj    : vector
            }
        }
        return fila;
    } catch (err) {
        console.error("Error en model/leeTablaBase "+parametro.tipo+" "+err);
        return ({status:500,message:"Error en model/leeTablaBase: "+parametro.tipo+" "+err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/leeTablaBase "+parametro.tipo+" "+err);
                return ({status:501,message:"Error en model/leeTablaBase: "+parametro.tipo+" "+err})
            }
        }
    }
}

async function grabaTablaBase(parametro) {
    let connection;
    let resultado;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        if (parametro.tipo=='grabaTabAntecedente'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABANTECEDENTE(:v_glosa,'+
                                                                    ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='grabaTabArticulo'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABARTICULO(:v_glosa,'+
                                                                 ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabAutoridad'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABAUTORIDAD(:v_glosa,'+
                                                                  ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabCalidad'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABCALIDAD(:v_glosa,'+
                                                                ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });        
        }else if (parametro.tipo=='grabaTabCargo'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABCARGO(:v_glosa,:v_tipo,'+
                                                              ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_tipo      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.tipoP},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });        
        }else if (parametro.tipo=='grabaTabEspecial'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABESPECIAL(:v_glosa,'+
                                                                 ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabMateria'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABMATERIA(:v_glosa,'+
                                                                ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabMotivo'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABMOTIVO(:v_glosa,'+
                                                               ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabPerfil'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABPERFIL(:v_glosa,'+
                                                               ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabPlantilla'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABPLANTILLA(:v_nombre,:v_asunto,:v_cuerpo,:v_remitente,:v_obs,'+
                                                                  ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_nombre    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.nombre},
                v_asunto    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.asunto},
                v_cuerpo    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.cuerpo},
                v_remitente : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.remitente},
                v_obs       : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.obs},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        // }else if (parametro.tipo=='grabaTabProcedencia'){ 
        //     const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABPROCEDENCIA(:v_glosa,'+
        //                                                             ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
        //     resultado = await connection.execute(sql, {
        //         v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
        //         v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
        //         v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
        //         v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
        //         v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
        //         v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
        //     }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabTipo'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABTIPO(:v_glosa,'+
                                                             ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;'; 
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabTipoAgr'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABTIPOAGR(:v_glosa,'+
                                                                ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabTipoDir'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABTIPODIR(:v_glosa,'+
                                                                ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabTipoDoc'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABTIPODOC(:v_glosa,'+
                                                                ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabTipoSol'){        
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABTIPOSOL(:v_glosa,'+
                                                                ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabTipoTra'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABTIPOTRA(:v_glosa,:v_cierre,'+
                                                                ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_cierre    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.cierre},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }else if (parametro.tipo=='grabaTabTramite'){
            const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_TABTRAMITE(:v_idTipo,:v_glosa,'+
                                                                ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_idTipo    : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idTipo},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        }      

        v_status     =resultado.outBinds.v_cod_error;
        v_message    =resultado.outBinds.v_msj_error;

        if (v_status==0){
            v_status=200;
        }
        let estado = {
            status     : v_status,
            message    : v_message
        }
        return estado;
    } catch (err) {
        console.error("Error en model/grabaTablaBase "+parametro.tipo+" "+err);
        return ({status:500,message:"Error en model/grabaTablaBase: "+parametro.tipo+" "+err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/grabaTablaBase "+parametro.tipo+" "+err);
                return ({status:501,message:"Error en model/grabaTablaBase: "+parametro.tipo+" "+err})
            }
        }
    }
}

async function actualizaTablaBase(parametro) {
    let connection;
    let fila;
    let estructura;
    let vector = [];
    let entro;
    let resultado;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        if (parametro.tipo=='actualizaTabAntecedente'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABANTECEDENTE(:v_id,:v_glosa,:v_vigente,'+
                                                                        ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabArticulo'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABARTICULO(:v_id,:v_glosa,:v_vigente,'+
                                                                     ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabAutoridad'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABAUTORIDAD(:v_id,:v_glosa,:v_vigente,'+
                                                                      ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabCalidad'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABCALIDAD(:v_id,:v_glosa,:v_vigente,'+
                                                                    ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabCargo'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABCARGO(:v_id,:v_glosa,:v_tipo,:v_vigente,'+
                                                                  ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_tipo      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.tipoP},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabEspecial'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABESPECIAL(:v_id,:v_glosa,:v_vigente,'+
                                                                     ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;'; 
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabMateria'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABMATERIA(:v_id,:v_glosa,:v_vigente,'+
                                                                    ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;'; 
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabMotivo'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABMOTIVO(:v_id,:v_glosa,:v_vigente,'+
                                                                   ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabPerfil'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABPERFIL(:v_id,:v_glosa,:v_vigente,'+
                                                                   ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabPlantilla'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABPLANTILLA(:v_id,:v_nombre,:v_asunto,:v_cuerpo,:v_remitente,:v_obs,:v_vigente,'+
                                                                      ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_nombre    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.nombre},
                v_asunto    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.asunto},
                v_cuerpo    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.cuerpo},
                v_remitente : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.remitente},
                v_obs       : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.obs},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });
        // }else if (parametro.tipo=='actualizaTabProcedencia'){ 
        //     const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABPROCEDENCIA(:v_id,:v_glosa,:v_vigente,'+
        //                                                                 ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
        //     resultado = await connection.execute(sql, {
        //         v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
        //         v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
        //         v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
        //         v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
        //         v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
        //         v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
        //         v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
        //         v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
        //     }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabTipo'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABTIPO(:v_id,:v_glosa,:v_vigente,'+
                                                                 ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabTipoAgr'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABTIPOAGR(:v_id,:v_glosa,:v_vigente,'+
                                                                    ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabTipoDir'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABTIPODIR(:v_id,:v_glosa,:v_vigente,'+
                                                                    ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabTipoDoc'){ 
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABTIPODOC(:v_id,:v_glosa,:v_vigente,'+
                                                                    ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabTipoSol'){        
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABTIPOSOL(:v_id,:v_glosa,:v_vigente,'+
                                                                    ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabTipoTra'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABTIPOTRA(:v_id,:v_glosa,:v_cierre,:v_vigente,'+
                                                                    ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_cierre    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.cierre},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }else if (parametro.tipo=='actualizaTabTramite'){
            const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_TABTRAMITE(:v_id,:v_idTipo,:v_glosa,:v_vigente,'+
                                                                    ':v_fecTran,:v_ipTran,:v_idUsuario,:v_cod_error,:v_msj_error); END;';
            resultado = await connection.execute(sql, {
                v_id        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.id},
                v_idTipo    : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idTipo},
                v_glosa     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.glosa},
                v_vigente   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
                v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
                v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
                v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
                v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
                v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
            }, { autoCommit: true });   
        }      

        v_status     =resultado.outBinds.v_cod_error;
        v_message    =resultado.outBinds.v_msj_error;

        if (v_status==0){
            v_status=200;
        }
        let estado = {
            status     : v_status,
            message    : v_message
        }
        return estado;
    } catch (err) {
        console.error("Error en model/actualizaTablaBase "+parametro.tipo+" "+err);
        return ({status:500,message:"Error en model/actualizaTablaBase: "+parametro.tipo+" "+err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/actualizaTablaBase "+parametro.tipo+" "+err);
                return ({status:501,message:"Error en model/actualizaTablaBase: "+parametro.tipo+" "+err})
            }
        }
    }
}

module.exports = {
    leeTablaBase,
    grabaTablaBase,
    actualizaTablaBase
//    leeTabTramite
};