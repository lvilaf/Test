'use restrict'

const oracledb  = require('oracledb');
const utilModel = require('../models/util.model');

async function leeUsuario(parametro) {
    let connection;
    let v_cod_error = 201;
    let v_msj_error = 'Usuario Sin Perfil';
    let v_salida= {};
    let v_usuario=[];
    let v_estructura=[];
    let v_idUsuario=0;
    let v_idPerfil=[];
    let v_perfil=[];

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN :v_cursor := PKG_TABLABASE.FN_LEE_USUARIO(:v_idUsuario,:v_idAutoridad,:v_rut,:v_dv,:v_apUno,:v_apDos,:v_nombre,:v_email,:v_username,:v_vigente); END;';      
        let result = await connection.execute(sql, {
            v_idUsuario  : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
            v_idAutoridad: { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idAutoridad},
            v_rut        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.rut},
            v_dv         : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.dv},
            v_apUno      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.apUno},
            v_apDos      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.apDos},
            v_nombre     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.nombre},
            v_email      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.email},
            v_username   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.username},
            v_vigente    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
            v_cursor     : { type: oracledb.CURSOR, dir: oracledb.BIND_INOUT }
        });

        const v_cursor2 = result.outBinds.v_cursor;
        let row; //Traer de a una fila
        let v_entro=0;
        while ((row = await v_cursor2.getRow())) {
            if (v_idUsuario!=row[0]){
                if (v_entro==1){
                    let v_obj={
                        idUsuario     : v_estructura.idUsuario,
                        idAutoridad   : v_estructura.idAutoridad,
                        glosaAutoridad: v_estructura.glosaAutoridad,
                        rut           : v_estructura.rut,
                        dv            : v_estructura.dv,
                        apUno         : v_estructura.apUno,
                        apDos         : v_estructura.apDos,
                        nombre        : v_estructura.nombre,
                        email         : v_estructura.email,
                        username      : v_estructura.username,
                        obs           : v_estructura.obs,
                        vigente       : v_estructura.vigente,
                        perfil        : v_perfil   
                    }
                    v_usuario.push(v_obj);
                }
                v_entro=1;
                v_idUsuario=row[0];
                v_idPerfil=[];
                v_perfil=[];
                v_estructura = {
                    idUsuario     : row[0],
                    idAutoridad   : row[1],
                    glosaAutoridad: row[2],
                    rut           : row[3],
                    dv            : row[4],
                    apUno         : row[5],
                    apDos         : row[6],
                    nombre        : row[7],
                    email         : row[8],
                    username      : row[9],
                    obs           : row[10],
                    vigente       : row[11]
                }
            }
            if (row[12]!=null && utilModel.existe(v_idPerfil,row[12])==0){
                v_obj = {
                    idPerfil :row[12],
                    glosa    :row[13],
                    vigente  :row[14]
                }
                v_perfil.push(v_obj);
                v_idPerfil.push(row[12]);
            }
        }
        await v_cursor2.close();
        if (v_estructura.length!=0){
            let v_obj={
                idUsuario     : v_estructura.idUsuario,
                idAutoridad   : v_estructura.idAutoridad,
                glosaAutoridad: v_estructura.glosaAutoridad,
                rut           : v_estructura.rut,
                dv            : v_estructura.dv,
                apUno         : v_estructura.apUno,
                apDos         : v_estructura.apDos,
                nombre        : v_estructura.nombre,
                email         : v_estructura.email,
                username      : v_estructura.username,
                obs           : v_estructura.obs,
                vigente       : v_estructura.vigente,
                perfil        : v_perfil
            }    
            v_usuario.push(v_obj);                   
        }                
        if (v_usuario.length==0){
            v_fila = {
                status : 400,
                message: 'No Existe Registro'
            };
        }else{
            v_fila = {
                status   : 200,
                message  : '',
                usuario  : v_usuario
            }    
        }
        return v_fila;
    } catch (err) {
        console.error("Error en model/leeUsuario " + err);
        return ({status:500,message:"Error en model/leeUsuario: " + err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/leeUsuario " + err);
                return ({status:501,message:"Error en model/leeUsuario: " + err})
            }
        }
    }
}

// function existe(array,elemento){
//     let resul=0;
//     for (let x=0;x<array.length;x++){
//         if (array[x]==elemento){
//             resul=1;
//         }
//     }
//     return resul;    
// }

async function grabaUsuario(parametro) {
    let connection;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN PKG_TABLABASE.PR_GRABA_USUARIO(:v_idUsuario,:v_idAutoridad,:v_rut,:v_dv,:v_apUno,:v_apDos,:v_nombre,:v_email,:v_username,:v_obs,'+
                                                         ':v_fecTran,:v_ipTran,:v_idUsuarioP,:v_cod_error,:v_msj_error); END;';
        let result = await connection.execute(sql, {
            v_idUsuario  : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
            v_idAutoridad: { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idAutoridad},
            v_rut        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.rut},
            v_dv         : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.dv},  
            v_apUno      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.apUno},
            v_apDos      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.apDos},
            v_nombre     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.nombre},
            v_email      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.email},
            v_username   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.username},
            v_obs        : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.obs},
            v_fecTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
            v_ipTran     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
            v_idUsuarioP : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuarioP},
            v_cod_error  : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
            v_msj_error  : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
        }, { autoCommit: true });

        v_status     =result.outBinds.v_cod_error;
        v_message    =result.outBinds.v_msj_error;

        if (v_status==0){
            v_status=200;
        }
        let estado = {
            status     : v_status,
            message    : v_message,
            obj        : {idUsuario:result.outBinds.v_idUsuario}
        }
        return estado;
    } catch (err) {
        console.error("Error en model/grabaUsuario " + err);
        return ({status:500,message:"Error en model/grabaUsuario: " + err})
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/grabaUsuario " + err);
                return ({status:501,message:"Error en model/grabaUsuario: " + err})
            }
        }
    }
}

async function actualizaUsuario(parametro) {
    let connection;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN PKG_TABLABASE.PR_ACTUALIZA_USUARIO(:v_idUsuario,:v_idAutoridad,:v_rut,:v_dv,:v_apUno,:v_apDos,:v_nombre,:v_email,:v_username,:v_obs,:v_vigente,'+
                                                             ':v_fecTran,:v_ipTran,:v_idUsuarioP,:v_cod_error,:v_msj_error); END;';     
        let result = await connection.execute(sql, {
            v_idUsuario  : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
            v_idAutoridad: { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idAutoridad},
            v_rut        : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.rut},
            v_dv         : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.dv},
            v_apUno      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.apUno},
            v_apDos      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.apDos},
            v_nombre     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.nombre},
            v_email      : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.email},
            v_username   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.username},
            v_obs        : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.obs},
            v_vigente    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.vigente},
            v_fecTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
            v_ipTran     : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
            v_idUsuarioP : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuarioP},
            v_cod_error  : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
            v_msj_error  : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
        }, { autoCommit: true });

        v_status     =result.outBinds.v_cod_error;
        v_message    =result.outBinds.v_msj_error;

        if (v_status==0){
            v_status=200;
        }
        let estado = {
            status     : v_status,
            message    : v_message
        }
        return estado;
    } catch (err) {
        console.error("Error en model/actualizaUsuario " + err);
        return ({status:500,message:"Error en model/actualizaUsuario: " + err})       
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/actualizaUsuario " + err);
                return ({status:501,message:"Error en model/actualizaUsuario: " + err})       
            }
        }
    }
}

async function borraUsuario(parametro) {
    let connection;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN PKG_TABLABASE.PR_BORRA_USUARIO(:v_idUsuario,'+
                                                         ':v_fecTran,:v_ipTran,:v_idUsuarioP,:v_cod_error,:v_msj_error); END;';     
        let result = await connection.execute(sql, {
            v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
            v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
            v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
            v_idUsuarioP: { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuarioP},
            v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
            v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
        }, { autoCommit: true });

        v_status     =result.outBinds.v_cod_error;
        v_message    =result.outBinds.v_msj_error;

        if (v_status==0){
            v_status=200;
        }
        let estado = {
            status     : v_status,
            message    : v_message
        }
        return estado;
    } catch (err) {
        console.error("Error en model/borraUsuario " + err);
        return ({status:500,message:"Error en model/borraUsuario: " + err})    
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/borraUsuario " + err);
                return ({status:501,message:"Error en model/borraUsuario: " + err})   
            }
        }
    }
}

async function leePermiso(parametro) {
    let connection;
    let v_perfil=[];

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN :v_cursor := PKG_GRABACION.FN_LEE_PERMISO(:v_idUsuario,:v_idPerfil,:v_fecPermiso); END;';      
        let result = await connection.execute(sql, {
            v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.idUsuario},
            v_idPerfil  : { type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: parametro.idPerfil},
            v_fecPermiso: { type: oracledb.STRING, dir: oracledb.BIND_IN, val: parametro.fecPermiso},
            v_cursor    : { type: oracledb.CURSOR, dir: oracledb.BIND_INOUT }
        });

        const v_cursor2 = result.outBinds.v_cursor;
        let row; //Traer de a una fila
        let v_fila = {
            status : 201,
            message: 'Usuario Sin Permiso',
            obj    : {}
        };

        let v_entro=0;
        while ((row = await v_cursor2.getRow())) {
            v_entro=1;
            let v_obj={
                idUsuario   : row[0],
                idPerfil    : row[1],
                fecPermiso  : row[2]
            }
            v_perfil.push(v_obj);
        }
        await v_cursor2.close();

        if (v_entro==1){
            v_fila = {
                status : 200,
                message: '',
                obj    : v_perfil
            }
        }
  
        return v_fila;
    } catch (err) {
        console.error("Error en model/leePermiso " + err);
        return ({status:500,message:"Error en model/leePermiso: " + err})   
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/leePermiso " + err);
                return ({status:501,message:"Error en model/leePermiso: " + err})
            }
        }
    }
}

async function grabaPermiso(parametro) {
    let connection;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN PKG_GRABACION.PR_GRABA_PERMISO(:v_idUsuario,:v_idPerfil,:v_fecPermiso,'+
                                                         ':v_fecTran,:v_ipTran,:v_idUsuarioP,:v_cod_error,:v_msj_error); END;';      
        let result = await connection.execute(sql, {
            v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
            v_idPerfil  : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idPerfil},
            v_fecPermiso: { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.fecPermiso},
            v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
            v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
            v_idUsuarioP: { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuarioP},
            v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
            v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
        }, { autoCommit: true });

        v_status     =result.outBinds.v_cod_error;
        v_message    =result.outBinds.v_msj_error;

        if (v_status==0){
            v_status=200;
        }
        let estado = {
            status     : v_status,
            message    : v_message
        }
        return estado;
    } catch (err) {
        console.error("Error en model/grabaPermiso " + err);
        return ({status:500,message:"Error en model/grabaPermiso: " + err})   
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/grabaPermiso " + err);
                return ({status:501,message:"Error en model/grabaPermiso: " + err})  
            }
        }
    }
}

async function borraPermiso(parametro) {
    let connection;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN PKG_GRABACION.PR_BORRA_PERMISO(:v_idUsuario,:v_idPerfil,'+
                                                         ':v_fecTran,:v_ipTran,:v_idUsuarioP,:v_cod_error,:v_msj_error); END;';     
        let result = await connection.execute(sql, {
            v_idUsuario : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuario},
            v_idPerfil  : { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idPerfil},
            v_idUsuarioP: { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuarioP},
            v_fecTran   : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: null},
            v_ipTran    : { type: oracledb.STRING, dir: oracledb.BIND_IN,   val: parametro.ipTran},
            v_idUsuarioP: { type: oracledb.NUMBER, dir: oracledb.BIND_IN,   val: parametro.idUsuarioP},
            v_cod_error : { type: oracledb.NUMBER, dir: oracledb.BIND_INOUT,val: null},
            v_msj_error : { type: oracledb.STRING, dir: oracledb.BIND_INOUT,val: null}
        }, { autoCommit: true });

        v_status     =result.outBinds.v_cod_error;
        v_message    =result.outBinds.v_msj_error;

        if (v_status==0){
            v_status=200;
        }
        let estado = {
            status     : v_status,
            message    : v_message
        }
        return estado;
    } catch (err) {
        console.error("Error en model/borraPermiso " + err);
        return ({status:500,message:"Error en model/borraPermiso: " + err})         
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/borraPermiso " + err);
                return ({status:501,message:"Error en model/borraPermiso: " + err}) 
            }
        }
    }
}

module.exports = {
    leeUsuario,
    grabaUsuario,
    actualizaUsuario,
    borraUsuario,
    leePermiso,
    grabaPermiso,
    borraPermiso
};