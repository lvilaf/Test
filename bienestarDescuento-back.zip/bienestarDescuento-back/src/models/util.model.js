'use restrict'

const { autoCommit } = require('oracledb');
const oracledb = require('oracledb');
const {parseString, Builder } = require('xml2js');
const config = require('../../config/config');

async function getVersion() {
    let fila = {
        status: 200,
        message: '0.0.07 04/12/2023'
    };
    return fila;
}

async function getVersionDB(variable) {
    let connection;
    let fila;
    let v_res=[];
//    let v_res='';

    try {
        let v_salida2;
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN :v_cursor := PKG_UTIL.FN_VERSION(); END;';
        let result = await connection.execute(sql, {
            v_cursor          : { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
        });

        const v_cursor2 = result.outBinds.v_cursor;
        let row; //Traer de a una fila

        while ((row = await v_cursor2.getRow())) {
            v_res.push(row[0]);
//                v_res += row[0]+'<br/>';
        }
        if (v_res.length==0){
            fila = {
                status: 400,
                message: 'Sin Packages',
                obj: {}
            };
        }else{
            fila = {
                status : 200,
                message: '',
                obj: v_res
            }    
        }
        await v_cursor2.close();
        return fila;
    } catch (err) {
        console.error("Error en model/getVersionDB: " + err);
        return ({status:500,message:'Error en model/getVersionDB: '+err});
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/getVersionDB: " + err);
                return ({status:501,message:'Error en model/getVersionDB: '+err});
            }
        }
    }
}

async function leeVar(variable) {
    let connection;
    let fila;

    try {
        let v_salida2;
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN :v_salida := PKG_UTIL.FN_VAR(:v_variable); END;';
        let result = await connection.execute(sql, {
            v_variable : { type: oracledb.STRING, dir: oracledb.BIND_IN , val:variable },
            v_salida   : { type: oracledb.STRING, dir: oracledb.BIND_OUT }
        });

        v_salida2 = (await result).outBinds.v_salida;

        if (v_salida2 == null) {
            fila = {
                status : 300,
                message: 0//"Variable No Encontrada"
            }
        } else {
            fila = {
                status : 200,
                message: v_salida2
            }
        } 

//        await result.outBinds.v_number.close();
        return fila;
    } catch (err) {
        console.error("Error en model/leeVar: " + err);
        return ({status:500,message:'Error en model/leeVar: '+err});
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/leeVar: " + err);
                return ({status:501,message:'Error en model/leeVar: '+err});
            }
        }
    }
}

async function leeTabPlantilla(idPlantilla) {
    let connection;
    let fila;

    try {
        //connection = await oracledb.getConnection({user: procesx.env.DB_ONEKEY_USER, password: procesx.env.DB_ONEKEY_PASS, connectString: procesx.env.DB_ONEKEY_CONNECT});
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN :v_cursor := PKG_UTIL.FN_LEE_PLANTILLA(:v_idPlantilla); END;';
        let result = await connection.execute(sql, {
            v_idPlantilla: {type: oracledb.NUMBER, dir: oracledb.BIND_IN, val: idPlantilla },
            v_cursor     : {type: oracledb.CURSOR, dir: oracledb.BIND_OUT                  }
        });		 
        
        let row = await result.outBinds.v_cursor.getRow(); //Traer de a una fila

        if (row == undefined) {
            fila = {
                status : 400,
                message: 'No encontró Plantilla '+idPlantilla,
                info   : {}
            };
        } else {
            fila = {
                status:200,
                message:'',
                info : row
            }
        }
        await result.outBinds.v_cursor.close();
        return fila;
    } catch (err) {
        console.error("Error en model/leeTabPlantilla: " + err);
        return ({status:500,message:'Error en model/leeTabPlantilla: '+err});        
    } finally { 
  		if (connection) {
  	        try {
  			    await connection.close();
  		    } catch (err) {
                console.error("Error en model/leeTabPlantilla: " + err);
                return ({status:501,message:'Error en model/leeTabPlantilla: '+err});
  		    }
	    }
    }
}

async function leeFechaHora() {
    let connection;
    let fila;
    let v_fechahora2;

    try {
        connection = await dbOraclePoolGlb.getConnection();
        const sql = 'BEGIN :v_fechahora := PKG_UTIL.FN_FECHA_HOY(:v_opcion); END;';
        let result = await connection.execute(sql, {
            v_opcion     : {type: oracledb.STRING, dir: oracledb.BIND_IN, val: 'C' },
            v_fechahora  : {type: oracledb.STRING, dir: oracledb.BIND_OUT          }
        });		 
        
        v_fechahora2 = (await result).outBinds.v_fechahora;

        if (v_fechahora2 == null) {
            fila = {
                status : 300,
                message: 0//"Variable No Encontrada"
            }
        } else {
            fila = {
                status : 200,
                message: v_fechahora2
            }
        } 

//        await result.outBinds.v_number.close();
        return fila;
    } catch (err) {
        console.error("Error en model/leeFechaHora: " + err);
        return ({status:500,message:'Error en model/leeFechaHora: '+err});
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error("Error en model/leeFechaHora: " + err);
                return ({status:501,message:'Error en model/leeFechaHora: '+err});
            }
        }
    }
}

function existe(array,elemento){
    let resul=0;
    for (let x=0;x<array.length;x++){
        if (array[x]==elemento){
            resul=1;
        }
    }
    return resul;    
}

function parseToString(value) {
    if (typeof (value) == "number")
        return value.toString();
    return value.toUpperCase();
}

function parseToDateString(value) {
    let parsedValue = value;
    if (typeof (value) == "number")
        parsedValue = value.toString();

    return parsedValue.replace(/-/g, '/');
}

function parseDate(str) {
    //function pad(x){return (((''+x).length==2) ? '' : '0') + x; }
    var m = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/)
        , d = (m) ? new Date(m[3], m[2] - 1, m[1]) : null
        , matchesPadded = (d && (str == [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/')))
        , matchesNonPadded = (d && (str == [d.getDate(), d.getMonth() + 1, d.getFullYear()].join('/')));
    return (matchesPadded || matchesNonPadded) ? d : null;

}

function toJson(xml) {
    let res;
    parseString(xml, { explicitArray: false }, function(error, result) {
        res=result;
    });
    return res;
  }  

// agrega 0 para los numeros menores que 10.
function pad(n) {
    return n < 10 ? '0' + n : n;
}


module.exports = {
    getVersion,
    getVersionDB,
    leeVar,
    leeTabPlantilla,
    leeFechaHora,
    existe,
    parseToString,
    parseToDateString,
    parseDate,
    toJson
};