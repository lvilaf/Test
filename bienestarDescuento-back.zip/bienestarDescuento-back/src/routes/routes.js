'use strict';

const express = require('express');
const usuarioController = require('../controllers/usuario.controller');
const archivoController = require('../controllers/archivo.controller');
const tablaBaseController = require('../controllers/tablaBase.controller');
const administracionController = require('../controllers/administracion.controller');
const utilController = require('../controllers/util.controller');
const auth = require('../middlewares/auth.middleware');
const authController = require('../controllers/auth-controller');
const config = require('../../config/config');
const api = express.Router();
var alfrescoController = require('../controllers/alfresco.controller');

api.get('/getVersion', utilController.getVersion);

api.get('/getVersionDB', utilController.getVersionDB);

//////////////////////////////////////////////////////////////////////////////

api.post('/loginCu', auth.isOrigin, authController.loginCu);

api.post('/claveUnica', auth.isOrigin, authController.claveUnica);

//////////////////////////////////////////////////////////////////////////////

api.post('/loginOneReg', auth.validaCaptcha, authController.loginOneReg);

api.post('/createOneReg', auth.validaCaptcha, authController.createOneReg);

api.post('/restoreOneReg', auth.validaCaptcha, authController.restoreOneReg);

api.post('/updateOneReg', auth.validaCaptcha, authController.updateOneReg);

//////////////////////////////////////////////////////////////////////////////

api.post('/login_ldap', auth.isOrigin, authController.loginLdap);

api.post('/lee_ldap', auth.isAuth, authController.leeLdap);

//////////////////////////////////////////////////////////////////////////////

api.post('/subir_alfresco', auth.isAuth, alfrescoController.subirAlfresco);

api.post('/bajar_alfresco', auth.isAuth, alfrescoController.bajarAlfresco);

api.post('/renombrar_alfresco', auth.isAuth, alfrescoController.renombrarAlfresco);

api.post('/borrar_alfresco', auth.isAuth, alfrescoController.borrarAlfresco);

//////////////////////////////////////////////////////////////////////////////

api.post('/lee_archivo', auth.isAuth, archivoController.leeArchivo);

api.post('/graba_archivo', auth.isAuth, archivoController.grabaArchivo);

api.post('/actualiza_archivo', auth.isAuth, archivoController.actualizaArchivo);

api.post('/borra_archivo', auth.isAuth, archivoController.borraArchivo);

//////////////////////////////////////////////////////////////////////////////

api.post('/lee_tabautoridad', auth.isAuth, tablaBaseController.leeTabAutoridad);

api.post('/graba_tabautoridad', auth.isAuth, tablaBaseController.grabaTabAutoridad);

api.post('/actualiza_tabautoridad', auth.isAuth, tablaBaseController.actualizaTabAutoridad);

api.post('/lee_tabperfil', auth.isAuth, tablaBaseController.leeTabPerfil);

api.post('/graba_tabperfil', auth.isAuth, tablaBaseController.grabaTabPerfil);

api.post('/actualiza_tabperfil', auth.isAuth, tablaBaseController.actualizaTabPerfil);

api.post('/lee_tabplantilla', auth.isAuth, tablaBaseController.leeTabPlantilla);

api.post('/graba_tabplantilla', auth.isAuth, tablaBaseController.grabaTabPlantilla);

api.post('/actualiza_tabplantilla', auth.isAuth, tablaBaseController.actualizaTabPlantilla);

//////////////////////////////////////////////////////////////////////////////

api.post('/lee_usuario', auth.isAuth, usuarioController.leeUsuario);

api.post('/graba_usuario', auth.isAuth, usuarioController.grabaUsuario);

api.post('/actualiza_usuario', auth.isAuth, usuarioController.actualizaUsuario);

api.post('/borra_usuario', auth.isAuth, usuarioController.borraUsuario);

api.post('/lee_permiso', auth.isAuth, usuarioController.leePermiso);

api.post('/graba_permiso', auth.isAuth, usuarioController.grabaPermiso);

api.post('/borra_permiso', auth.isAuth, usuarioController.borraPermiso);

//////////////////////////////////////////////////////////////////////////////

api.post('/mant_graba_usuario', auth.isAuth, administracionController.mantGrabaUsuario);

api.post('/mant_actualiza_usuario', auth.isAuth, administracionController.mantActualizaUsuario);

api.post('/mant_borra_usuario', auth.isAuth, administracionController.mantBorraUsuario);

api.post('/lee_var', auth.isAuth, utilController.leeVar);

//////////////////////////////////////////////////////////////////////////////

api.post('/convertir_archivo_excel', auth.isAuth, archivoController.convertirArchivoExcel);
api.post('/leer_archivo_excel', auth.isAuth, archivoController.leerArchivoExcelaJSON);

///////////////////////////////////////////////////////////////////////////////

module.exports = api;