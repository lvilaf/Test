'use strict'

const jwt = require('jwt-simple');
const moment = require('moment');
const config = require('../../config/config');
let tiempo;
let unidad;

function createToken(login) {

    if (login.origin == config.ORIGIN_AUTH_DESA) {
        tiempo = config.TIEMPO_DESA;
        unidad = config.UNIDAD_DESA;
    } else {
        tiempo = config.TIEMPO;
        unidad = config.UNIDAD;
    } 
    const payload = {
        sub: { rut: login.rut, ipTran: login.ipTran, origin: login.origin },
        iat: moment().unix(),
        exp: moment().add(tiempo, unidad).unix()
    };

    return jwt.encode(payload, config.SECRET_TOKEN);
}

function decodeToken(token) {
    const decoded = new Promise((resolve, reject) => {
        try {
            const payload = jwt.decode(token, config.SECRET_TOKEN);

            if (payload.exp <= moment().unix()) {
                reject({
                    status: 401,
                    message: 'Tiempo de Sesión Expirado'
                });
            } else {
                resolve(payload.sub);
            }
        } catch (err) {
            reject({
                status: 403,
                message: 'Tiempo de Sesión Inválido'
            });
        }
    });
    return decoded;
}

module.exports = {
    createToken,
    decodeToken
};